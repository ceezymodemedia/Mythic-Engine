# Hidden in Chest - SonicMetrix Semantic Analysis

## Scores

- Totality: 0.720
- Framework adherence: 0.811
- Structural coherence: 0.727
- Modularity: 0.692
- Semantic summons: 0.360
- Local priority alignment: 0.656
- Model agency credit: 0.880
- Signal integrity: 0.818

## Temporal / Rhythm / Pitch

- Duration: 239.08s
- Tempo estimate: 70 BPM (confidence 0.15)
- Key estimate: B major (confidence 0.56)
- Onset proxy count: 116
- Low drum proxy count: 59
- Snare/mid-hit proxy count: 36

## Local Priority Interpretation

- Score: 0.656
- Priority peak score: 0.640
- Zero valley score: 0.685
- Meaning: 10 is evaluated as local priority/attention, not always absolute loudness.

## Semantic Summons

- Semantic summons score: 0.360
- Cue count: 7

- breath at 57.0s: response 0.628, events onset_proxy_34, onset_proxy_35, kick_proxy_36, onset_proxy_37, onset_proxy_38
- ash at 76.0s: response 0.425, events onset_proxy_51, onset_proxy_52, snare_proxy_53, onset_proxy_54, kick_proxy_55
- gate at 101.0s: response 0.560, events onset_proxy_87, onset_proxy_88, onset_proxy_89, kick_proxy_90
- chain at 123.0s: response 0.100, events onset_proxy_95, kick_proxy_96
- hammer at 146.0s: response 0.505, events onset_proxy_111, onset_proxy_112, kick_proxy_113, onset_proxy_114, snare_proxy_115
- light at 172.0s: response 0.265, events 
- silence at 202.0s: response 0.035, events onset_proxy_163, kick_proxy_164, onset_proxy_165, snare_proxy_166, onset_proxy_167

## Prompt-Act Estimate

| Act | Window | Intended Avg | Observed Avg | Adherence |
| --- | ---: | ---: | ---: | ---: |
| Extended Musical Prelude | 0.0-27.6s | 1.00 | 2.54 | 0.85 |
| Breath / Hidden Chest | 27.6-55.2s | 1.00 | 4.13 | 0.69 |
| Ash Verse | 55.2-82.8s | 2.33 | 4.65 | 0.77 |
| Gate / Chain | 82.8-137.9s | 4.33 | 5.25 | 0.91 |
| Hammer / Light | 137.9-193.1s | 6.33 | 5.89 | 0.96 |
| Silence / Final Summons | 193.1-239.1s | 2.60 | 5.61 | 0.70 |

## Human Listening Notes

- Drums follow the schema by ear, with felt 10-level impacts and silence between 0s justifying the energy explosions.
- Suno plays with a long melody/music structure before fully committing to the lyrical beginning around 57 seconds.
- Suno treats 10 conceptually: a 10 is local priority rather than always the biggest possible sound.
- Another breathy persona voice appears, and breaths follow the semantic style descriptions.
- Suno appears to respond better to directional branching paths than strict literal commands.
