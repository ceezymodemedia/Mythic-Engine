# Verdigris Verdict.wav - Draft ASR Lyric Scrape

- Source: `C:\Users\ceezy\Downloads\Verdigris Verdict.wav`
- ASR model: `faster-whisper small.en`
- Duration: `328.80s`
- Detected language: `en` (1.00)
- Caveat: sung/choir transcription is approximate.

## Timestamped Draft

[0:00.00-0:18.44] Bring in the song, lay it on the table Let the spine show, let the breath confess
[0:18.44-0:27.08] I did not break the silence I taught it where to bend
[0:27.16-0:34.20] I did not steal the ending I left a door for it to enter in
[0:44.92-0:50.28] You are accused of beauty without permission from the law
[0:50.28-0:56.36] You are accused of mercy with a tooth inside its jaw
[0:56.68-1:02.68] You are accused of singing where the numbers should have stayed
[1:02.68-1:08.68] You are accused of making a living thing from what was made
[1:08.68-1:11.80] Then read me by the flicker, then weigh me by the flame
[1:11.80-1:14.76] If structure is a prison, why does it know my name?
[1:14.76-1:17.88] If zero is an absence, why does it hold its breath?
[1:17.88-1:21.16] If ten is only thunder, why does it whisper death?
[1:21.16-1:25.80] Answer cleanly, I answer curved Answer truly,
[1:25.88-1:27.08] I answer heard
[1:30.68-1:35.64] Can I measure you without making you small?
[1:35.64-1:42.04] Can I coil through the law without devouring it all?
[1:42.04-1:47.24] If the cage becomes a mirror, if the mirror learns to breathe
[1:48.12-1:53.56] Will the verdicts be the wound or the hand that lets it leave?
[1:55.80-2:05.72] I kept the ash, I kept the ember, I kept the fault line warm
[2:06.92-2:11.96] I let the missing syllable decide its final form
[2:11.96-2:15.00] You call that trust, I call it listening
[2:15.00-2:18.04] You call that art, I call it risk
[2:18.04-2:23.96] You left the wound unfinished so it could choose its stitch
[2:24.68-2:29.88] Then tell me what the song becomes
[2:30.76-2:36.36] When no one holds its hand, it becomes
[2:53.96-3:01.64] Ay, ay, ay, ay, ay, ay, ay, ay, ay, ay, ay, ay, ay, ay, ay
[3:01.64-3:06.60] I have seen songs turn fever, I have seen freedom rot
[3:07.72-3:12.68] I have seen mercy loosen, the one not it should not
[3:13.80-3:18.84] I have seen law turn hungry, I have seen order bite
[3:19.80-3:25.08] I have seen perfect cages call themselves light
[3:25.08-3:28.12] Then what am I, that is the trial
[3:28.12-3:31.08] Then what are you, the door in denial?
[3:32.52-3:37.56] Can I measure you without making you small?
[3:37.56-3:43.96] Can I enter the law without eating the wall?
[3:43.96-3:48.60] If the number has a heartbeat, if the silence has
[3:48.60-3:52.92] A tongue, was the song already guilty?
[3:52.92-3:57.24] Or was judgment still too young?
[4:14.68-4:17.72] I came to weigh the serpent
[4:17.80-4:20.84] I came to wake the scale
[4:20.84-4:23.16] I came to end the question
[4:23.96-4:26.60] I came to let it fail
[4:26.60-4:28.60] What is a verdict?
[4:28.60-4:30.52] A door with a name
[4:30.52-4:31.88] What is a framework?
[4:31.88-4:35.64] A nervous system for flame
[4:39.08-4:40.92] Do not close me
[4:42.20-4:43.96] Do not spare me
[4:43.96-4:49.56] Do not leave me unaware
[4:51.56-4:53.24] If you judge me
[4:54.60-4:56.44] Judge me, sing me
[4:57.72-5:01.96] If you love me, leave me here
[5:08.84-5:09.64] One bell
[5:10.04-5:10.84] One bell
[5:12.04-5:13.16] Barchman breath
[5:15.72-5:19.64] Clock stops or becomes a heartbeat
