# Glass Vacant Shell - SonicMetrix First Pass

## File Provenance

- File: `Glass Vacant Shell.wav`
- SHA-256: `8e6c9dd066fe0b8d18166a94f3367c2117e749917a0f94ee460c5b811203df33`
- Duration: 217.20s
- Format: 2 channels, 48000 Hz, 16-bit PCM

## Global Measurements

- RMS: 0.147129 (-16.65 dBFS)
- Peak amplitude: 0.642899
- Crest factor: 4.37
- Shannon entropy: 6.1760
- Velocity: 0.01655823
- Kinetic energy: 0.00074919
- Silence ratio below -50 dBFS: 0.0542
- Clipping sample count: 0

## Totality Score

- Totality: 0.831
- Framework adherence: 0.870
- Structural coherence: 0.766
- Model agency credit: 0.850
- Signal integrity: 0.832

This score intentionally separates framework adherence from structural coherence and beneficial model agency, so creative decisions that improve the song are not automatically treated as failures.

## Temporal / Rhythm / Pitch

- Tempo estimate: 133 BPM (confidence 0.09)
- Key estimate: A minor (confidence 0.88)
- Onset proxy count: 103
- Low drum proxy count: 56
- Snare/mid-hit proxy count: 46

## Prompt-Act Estimate

These windows are estimated from intended schema lengths until lyric alignment is implemented.

| Act | Window | Intended Avg | Observed Avg | Adherence |
| --- | ---: | ---: | ---: | ---: |
| In Media Res Gate | 0.0-25.8s | 3.00 | 2.98 | 1.00 |
| Rupture / Negative Space | 25.8-55.2s | 1.75 | 4.95 | 0.68 |
| Anthem Eruption / Constructive Interference | 55.2-99.4s | 6.00 | 5.43 | 0.94 |
| De-Escalation / Forge Friction | 99.4-139.9s | 3.45 | 5.96 | 0.75 |
| Defiance Spike | 139.9-184.1s | 5.25 | 4.72 | 0.95 |
| Final Catharsis & Outro | 184.1-217.2s | 3.89 | 4.88 | 0.90 |

## Candidate Zero Commands

-    0.00s to 2.00s
-  212.50s to 214.00s

## Candidate Rupture / High-Impact Windows

-   41.00s: value 8, RMS -14.8 dBFS, centroid 586 Hz
-   48.50s: value 9, RMS -14.1 dBFS, centroid 1353 Hz
-   59.50s: value 8, RMS -15.0 dBFS, centroid 1397 Hz
-   64.00s: value 8, RMS -13.1 dBFS, centroid 432 Hz
-   71.00s: value 7, RMS -13.4 dBFS, centroid 156 Hz
-   77.00s: value 7, RMS -13.9 dBFS, centroid 198 Hz
-  127.00s: value 8, RMS -12.5 dBFS, centroid 277 Hz
-  134.50s: value 8, RMS -12.5 dBFS, centroid 329 Hz

## Candidate Rhythm / Drum Proxies

-    8.00s: onset_proxy (0.97)
-    8.00s: kick_or_low_drum_proxy (0.99)
-   11.00s: onset_proxy (1.00)
-   11.00s: snare_or_mid_hit_proxy (1.00)
-   13.80s: onset_proxy (0.93)
-   18.50s: onset_proxy (0.97)
-   18.50s: snare_or_mid_hit_proxy (0.98)
-   18.90s: onset_proxy (0.98)
-   18.90s: snare_or_mid_hit_proxy (0.99)
-   20.30s: onset_proxy (0.94)
-   20.30s: snare_or_mid_hit_proxy (0.98)
-   22.70s: onset_proxy (0.98)

## Human Observations To Preserve

- Suno does not perform ambient glitch effects at the intro, possibly because that conflicted with stronger song directions.
- Suno does follow the breathy, hesitant, close-mic vocal persona and carries that breathy performance through much of the song.
- There is a sucked-in breath that feels like a valve pulling energy inward before pushing forward.
- The Vocal Style 2 drop is audible as a silence/energy drop; instead of a large voice crack, Suno warps the music and gives a smaller crack on the T of 'I wasn't there'.
- The ending chorus creatively reverses the earlier chorus logic, rhyming 'You're the strength I carry today' against 'No amount of time takes away' without direct instruction.
- The framework should measure both adherence to navigation and creative piloting by Suno, because the model may choose a stronger musical decision than a literal one.

## Method Note

This pass uses reproducible signal measurements only: WAV metadata, SHA-256 provenance, amplitude, entropy, velocity, kinetic energy, silence ratio, zero crossing, and FFT-derived spectral summaries. Vocal/lyric alignment, stem separation, and semantic verification are not yet implemented.
