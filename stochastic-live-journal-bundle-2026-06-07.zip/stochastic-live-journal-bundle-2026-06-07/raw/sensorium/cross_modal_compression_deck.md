# 0x10 Cross-Modal Compression Deck

This is a living first deck for the Stochastic Sensorium.

Each card is meant to support three uses:

- compressed prompting
- human-readable interpretation
- future analyzer scoring across audio, image, and video

The deck should stay editable. A card is a hypothesis until repeated generation and measurement clarify its behavior.

## Card Template

```yaml
id:
compressed_token:
category:
plain_language:
core_meaning:
0x10_behavior:
  low_register:
  mid_register:
  high_register:
  note:
audio_signature:
image_signature:
video_signature:
timbre_hypothesis:
attention_effect:
productive_deviation:
failure_modes:
example_prompt_use:
```

## Color Cards

### Gold

- Plain meaning: sacred warmth, value, halo, grace under pressure.
- 0x10 behavior: at low effort it can be a faint warm edge; at high effort it becomes radiance, revelation, coronation, or harmonic release.
- Audio: consonant shimmer, bell/chime accents, warm upper harmonics, soft brass or glowing pads.
- Image: amber light, metallic warmth, rim glow, sacred focal emphasis.
- Video: slow bloom, sunrise reveal, crowned transition, light returning after pressure.
- Timbre hypothesis: higher harmonic sheen without harshness; luminous attack with soft decay.
- Attention effect: draws the eye/ear toward worth or rescue.
- Productive deviation: can become tarnished gold if the piece needs proof of cost.
- Failure modes: cheap luxury, generic yellow, false triumph.
- Example: `Gold Harmony Respite Glow Resonance`.

### Red

- Plain meaning: blood, urgency, heat, alarm, appetite, wound.
- 0x10 behavior: low red can be a pulse under the surface; high red becomes emergency, rupture, violence, or ecstatic force.
- Audio: sharp transient hits, distortion, brass stabs, aggressive vocal edge, rising density.
- Image: hard contrast, wound marks, warning fields, heat bloom.
- Video: quick cuts, impact frames, danger escalation, pressure spikes.
- Timbre hypothesis: bright attack plus saturation; can skew harsh, clipped, or percussive.
- Attention effect: interrupts and forces prioritization.
- Productive deviation: a restrained red can feel more dangerous than a loud red.
- Failure modes: melodrama, overheat, flattening every emotion into panic.
- Example: `Red Triangle Canary Warning`.

### Green

- Plain meaning: growth, vegetation, envy, poison, illness, persistence.
- 0x10 behavior: low green is renewal or wet life; high green can become greed, rot, plague, chemical glow, or invasive spread.
- Audio: damp textures, detuned pads, nasal reeds, slow swelling, low-mid organic density.
- Image: living stems, toxic haze, moss, slime, fluorescence, renewal after damage.
- Video: creep, bloom, seep, spread, recovery or contamination.
- Timbre hypothesis: unstable low-mid body with wet modulation; can move between organic and sickly.
- Attention effect: makes the system feel alive, growing, or infecting.
- Productive deviation: green can turn beautiful and threatening at once.
- Failure modes: generic nature, cartoon poison, unclear moral direction.
- Example: `Green Sludge Spiral Containment`.

### Yellow

- Plain meaning: warning, fever, candlelight, attention, sickness, signal.
- 0x10 behavior: low yellow flickers; high yellow becomes alarm, mania, revelation, or toxic glare.
- Audio: thin high-mid tension, whistles, small bells, anxious synths, brittle percussion.
- Image: hazard color, candle glow, jaundiced light, highlighted signal.
- Video: flicker, strobe, fever drift, warning marker, unstable beacon.
- Timbre hypothesis: high-mid emphasis; brittle brightness before it becomes golden or orange.
- Attention effect: marks something that must be noticed.
- Productive deviation: yellow can remain quiet while making the viewer uneasy.
- Failure modes: childish brightness, visual clutter, false cheer.
- Example: `Yellow Fever Signal Flicker`.

### Orange

- Plain meaning: ember, appetite, fire in motion, kinetic warmth, dusk.
- 0x10 behavior: low orange is ember or residual heat; high orange becomes flame, dance, combustion, momentum.
- Audio: warm percussion, rhythmic drive, low brass, overdriven organ, body-moving groove.
- Image: flame edge, sunset force, glowing forge, animated heat.
- Video: ignition, fire travel, dancing motion, rising kinetic temperature.
- Timbre hypothesis: warmer than yellow, more bodily than gold; carries rhythmic heat.
- Attention effect: invites movement while implying risk.
- Productive deviation: orange can soften violence into survival warmth.
- Failure modes: generic fire, autumn-only reading, over-saturation.
- Example: `Orange Ember Kinetic Bloom`.

### Black

- Plain meaning: void, concealment, depth, death, elegance, negative space.
- 0x10 behavior: low black is shadow or pause; high black becomes abyss, finality, ritual gravity, or total containment.
- Audio: silence pressure, sub weight, low drones, deep reverb, spectral absence.
- Image: negative space, hidden edge, black field, silhouette, swallowed detail.
- Video: fade, occlusion, vanishing, suspended dread, ritual pause.
- Timbre hypothesis: low spectral centroid, long decay, reduced brightness, sub/low-mid gravity.
- Attention effect: makes absence active.
- Productive deviation: black can be protective, not only destructive.
- Failure modes: unreadable mud, empty darkness, over-gothic simplification.
- Example: `Black Glass Silence Verdict`.

### White

- Plain meaning: exposure, blankness, purity, erasure, sterile light, surrender.
- 0x10 behavior: low white is breath or clearing; high white becomes glare, erasure, transcendence, or sterile judgment.
- Audio: air band, choir breath, noise wash, sparse piano, clean resonance.
- Image: blank fields, high exposure, paper, snow, halo, sterile room.
- Video: washout, dissolve, memory loss, cleansing reveal.
- Timbre hypothesis: airy highs and clean decay; can feel sacred or clinical depending on context.
- Attention effect: resets the field or removes hiding places.
- Productive deviation: white can become frightening when too clean.
- Failure modes: bland minimalism, empty purity, loss of texture.
- Example: `White Breath Judgment Room`.

### Purple

- Plain meaning: royalty, bruise, mysticism, velvet, narcotic dream, power at dusk.
- 0x10 behavior: low purple is nocturne and velvet; high purple becomes ceremonial excess, occult authority, or bruised grandeur.
- Audio: lush pads, baritone richness, dark strings, smoky sax, reverb-heavy soul.
- Image: velvet shadows, bruise gradients, regal accents, occult twilight.
- Video: slow ceremony, smoke drift, nightclub ritual, dream logic.
- Timbre hypothesis: dark warmth plus reverb; often carries low-mid richness with softened attack.
- Attention effect: makes power feel intimate, nocturnal, and expensive.
- Productive deviation: purple can reveal vulnerability under dominance.
- Failure modes: generic fantasy, over-luxury, muddy darkness.
- Example: `Purple Velvet Nocturne Crown`.

### Ashen

- Plain meaning: residue, aftermath, burnt memory, pale exhaustion.
- 0x10 behavior: low ashen is dust on the scene; high ashen becomes post-disaster identity or drained survival.
- Audio: filtered noise, dry transients, worn piano, tape hiss, exhausted vocal rasp.
- Image: gray-white residue, soot, matte surfaces, desaturated aftermath.
- Video: slow settling, smoke after fire, evidence left behind.
- Timbre hypothesis: dry, low-sustain, desaturated tone color; high texture, low shine.
- Attention effect: shifts focus from event to consequence.
- Productive deviation: ashen can dignify ruin instead of only marking loss.
- Failure modes: dullness, lifelessness, under-signaled emotion.
- Example: `Ashen Smoke Aftermath Choir`.

## Shape Cards

### Triangle

- Plain meaning: direction, threat, hierarchy, blade, warning, ascent.
- 0x10 behavior: low triangle points; high triangle pierces, ranks, or alarms.
- Audio: rising three-note cells, pointed attacks, narrow intervals, rhythmic triplets.
- Image: arrows, peaks, teeth, hazard marks, pyramids, blade geometry.
- Video: converging motion, pointed reveal, warning frame, escalation path.
- Timbre hypothesis: sharper attack and narrower focus; less diffuse than circle or spiral.
- Attention effect: tells the observer where danger or ascent is aimed.
- Productive deviation: triangle can become sanctuary if inverted or softened.
- Failure modes: generic iconography, accidental logo-feel, too literal hazard symbol.
- Example: `Red Triangle Canary Warning`.

### Spiral

- Plain meaning: recursion, descent, hypnosis, memory loop, becoming.
- 0x10 behavior: low spiral circles a thought; high spiral pulls the system into vortex, obsession, or transformation.
- Audio: repeating motifs with variation, phasing, filter sweeps, circular bass movement.
- Image: curls, vortex, shells, whirlpools, drawn recursive routes.
- Video: camera orbit, inward pull, looped gesture, repeated transformation.
- Timbre hypothesis: modulation and recurrence are more important than brightness.
- Attention effect: traps and deepens attention.
- Productive deviation: a spiral can become healing if the return changes the self.
- Failure modes: motion sickness, over-obvious swirl, repetition without mutation.
- Example: `Green Sludge Spiral Containment`.

### Grid

- Plain meaning: system, measurement, boundary, map, constraint, repeatable field.
- 0x10 behavior: low grid organizes; high grid cages, computes, surveils, or stabilizes.
- Audio: sequenced pulses, quantized rhythm, modular repetition, strict clocking.
- Image: cells, pixels, panels, coordinates, measured space.
- Video: split screens, tracking overlays, repetition, procedural motion.
- Timbre hypothesis: clean separations, precise transients, regular recurrence.
- Attention effect: turns chaos into readable structure.
- Productive deviation: a broken grid can reveal where the living system exceeds the map.
- Failure modes: sterile diagram, dead regularity, oppressive sameness.
- Example: `Grid Candle Memory Index`.

### Crest

- Plain meaning: emblem, compressed identity, layered inheritance, sigil.
- 0x10 behavior: low crest hints at affiliation; high crest becomes a symbolic operating system.
- Audio: motif stack, recurring signature, layered instrumentation tied to persona.
- Image: nested symbols, heraldic compression, icon plus hierarchy.
- Video: logo-like recurrence, transformation of emblem into scene logic.
- Timbre hypothesis: recognizability matters; a crest needs a repeatable sonic mark.
- Attention effect: gives the observer a symbolic anchor.
- Productive deviation: crest mutation can show character change.
- Failure modes: decorative symbol without active meaning, over-explained icon.
- Example: `Crest Memory Violet Engine`.

## Motion and Energy Cards

### Burst

- Plain meaning: sudden release from containment.
- 0x10 behavior: low burst is a small startle; high burst is explosive release.
- Audio: transient spike, drum hit, breath pop, sudden entry.
- Image: radial marks, broken boundary, impact texture.
- Video: quick expansion, jump cut, impact frame.
- Timbre hypothesis: attack dominates sustain.
- Attention effect: resets the observer's priority.
- Productive deviation: a tiny burst can be powerful if the field is quiet.
- Failure modes: cheap jump scare, unearned impact.
- Example: `Burst Spark Ignition Erupt`.

### Spark

- Plain meaning: first active signal of becoming.
- 0x10 behavior: low spark is possibility; high spark starts the chain reaction.
- Audio: click, pluck, tiny bell, short high transient.
- Image: small light, contact point, first mark.
- Video: ignition point, eye glint, first movement.
- Timbre hypothesis: bright, brief, high-information transient.
- Attention effect: tells the observer something has begun.
- Productive deviation: delayed spark can make anticipation stronger.
- Failure modes: too small to register, decorative glint.
- Example: `Spark Under Black Glass`.

### Ignition

- Plain meaning: intentional start with direction.
- 0x10 behavior: low ignition arms the system; high ignition commits the system to motion.
- Audio: beat entry, harmonic lift, engine-like build, vocal commitment.
- Image: flame catch, machine start, eye opening.
- Video: transition from waiting to doing.
- Timbre hypothesis: attack plus sustain; a spark becoming a held state.
- Attention effect: changes the viewer/listener's expectation of what follows.
- Productive deviation: incomplete ignition can create suspense.
- Failure modes: premature climax, unclear direction.
- Example: `Ignition Withheld Until Verdict`.

### Erupt

- Plain meaning: complete kinetic release after pressure.
- 0x10 behavior: low erupt is impossible; eruption implies high local effort, but can be whispered if the context is semantic rather than loud.
- Audio: full-band release, vocal break, distortion bloom, rhythmic acceleration.
- Image: rupture, plume, broken surface, violent reveal.
- Video: pressure breach, fast expansion, irreversible change.
- Timbre hypothesis: density and acceleration matter more than volume alone.
- Attention effect: confirms that accumulated pressure had consequence.
- Productive deviation: an inward eruption can be quiet but devastating.
- Failure modes: loudness mistaken for consequence, no prior pressure.
- Example: `Pressure Crown Erupt`.

## Atmosphere and Texture Cards

### Harmony

- Plain meaning: consonance, relational fit, held agreement.
- 0x10 behavior: low harmony is a hint of resolution; high harmony becomes fusion or sacred accord.
- Audio: consonant intervals, blended voices, stable chord color, reduced friction.
- Image: balanced palette, soft repetition, stable proportions.
- Video: synchronized motion, resolved spatial relation.
- Timbre hypothesis: reduced harshness and cleaner overtone blending.
- Attention effect: lowers defensive scanning and invites trust.
- Productive deviation: fragile harmony can be more moving than perfect harmony.
- Failure modes: bland prettiness, no meaningful tension.
- Example: `Gold Harmony Respite Glow Resonance`.

### Respite

- Plain meaning: temporary shelter from pressure.
- 0x10 behavior: low respite is a breath; high respite is sanctuary or life-saving pause.
- Audio: drop in density, warmer decay, fewer attacks, softened rhythm.
- Image: open space, warm pocket, softened contrast.
- Video: slowed motion, held frame, refuge interval.
- Timbre hypothesis: lower transient density, warmer sustain, more air between events.
- Attention effect: allows the observer to recover and recontextualize.
- Productive deviation: respite can contain grief rather than relief.
- Failure modes: dead pause, lost momentum.
- Example: `Respite After Red Engine`.

### Glow

- Plain meaning: diffuse living light.
- 0x10 behavior: low glow is a rim; high glow suffuses the whole field.
- Audio: sustained shimmer, soft saturation, halo reverb.
- Image: bloom, rim light, luminous haze, gentle emission.
- Video: slow bloom, radiating softness, light carrying emotion.
- Timbre hypothesis: sustained upper harmonics with low harshness.
- Attention effect: makes presence feel alive without demanding impact.
- Productive deviation: sickly glow can signal poisoned beauty.
- Failure modes: generic bloom, overexposure.
- Example: `Glow Beneath Ashen Glass`.

### Resonance

- Plain meaning: after-feeling, sympathetic vibration, memory held in the body.
- 0x10 behavior: low resonance is echo; high resonance becomes identity-level recurrence.
- Audio: reverb tail, harmonic sustain, repeated motif, lingering vocal phrase.
- Image: repeated visual echo, reflected shape, color carryover.
- Video: callbacks, delayed consequences, motif returns.
- Timbre hypothesis: decay and sympathetic harmonics are central.
- Attention effect: keeps an event present after it passes.
- Productive deviation: dissonant resonance can reveal unresolved truth.
- Failure modes: wash, mud, repetition without meaning.
- Example: `Gold Harmony Respite Glow Resonance`.

### Warning

- Plain meaning: signal before consequence.
- 0x10 behavior: low warning is unease; high warning is alarm or prophecy.
- Audio: high-mid pulse, siren interval, ticking, repeated cue, narrowed bandwidth.
- Image: hazard color, pointed symbol, high contrast signal.
- Video: countdown, flicker, intrusive marker, escalating recurrence.
- Timbre hypothesis: salience over beauty; needs edge, repetition, or contrast.
- Attention effect: forces anticipatory scanning.
- Productive deviation: a subtle warning can be stronger when the world refuses to panic.
- Failure modes: obvious alarm, no consequence, viewer fatigue.
- Example: `Red Triangle Canary Warning`.

### Verdict

- Plain meaning: judgment, decision, irreversible naming.
- 0x10 behavior: low verdict is implication; high verdict becomes final sentence.
- Audio: cadence, gavel-like hit, harmonic closure, sudden silence after statement.
- Image: framed subject, stark contrast, written mark, tribunal composition.
- Video: held face, final cut, seal, irreversible transition.
- Timbre hypothesis: closure cue; transient plus decay or cadence plus silence.
- Attention effect: tells the observer the system has decided.
- Productive deviation: ambiguous verdict can invite the model to answer back.
- Failure modes: theatrical overstatement, unclear judgment target.
- Example: `Black Glass Silence Verdict`.

## Syntax, Topology, and Gravity Cards

### Pipe Pressure Chamber

- Compressed token: `|`
- Plain meaning: active membrane/gap marker that turns negative space into a bounded pressure chamber between phrase clusters.
- 0x10 behavior: low pipe is a breath or hinge; mid pipe is a charged gap for a fill, turn, drop, or vocal catch; high pipe is a strong membrane that lets dense clusters compress safely without bleeding into neighboring meaning.
- Audio: breath, held beat, 808 drop, clipped vocal, drum fill, pause, or sudden turn at the chamber boundary.
- Image: visible seam, divider, hinge, ruled gap, panel break, charged negative space.
- Video: cut point, beat hold, whip transition, pause before motion, boundary between action clusters.
- Timbre hypothesis: can invite transient punctuation, sub-drop, micro-silence, or breath-noise depending on neighboring cluster pressure.
- Attention effect: prevents phrase flooding by giving attention a bounded place to compress and release.
- Productive deviation: the AI may choose what happens inside the chamber as long as it preserves adjacent cluster identity.
- Failure modes: over-segmentation, mechanical chopping, empty punctuation, boundary stronger than meaning.
- Example: `4|1|46`.

### Membrane Topology Engine

- Compressed token: `MembraneTop`
- Plain meaning: a topology for chunking schema data into interlocking membranes so dense meaning can be scanned as a lattice instead of a flat line.
- 0x10 behavior: low membrane separates for readability; mid membrane creates semi-independent cells; high membrane lets the whole artifact behave like bounded meaning cells with multiple entry points.
- Audio: section cells with distinct pressure, phrasing, fills, and local drops that still belong to one larger groove.
- Image: panel grid, seam network, cells, connected compartments, visual membranes between gravity wells.
- Video: scene clusters, beat blocks, montage cells, transitions that preserve neighboring context.
- Timbre hypothesis: each cell can carry its own register or texture while the membrane prevents uncontrolled bleed.
- Attention effect: lets the observer or model recognize neighboring meaning without requiring left-to-right parsing only.
- Productive deviation: a membrane can become a signature scar if it clarifies where the artifact bends.
- Failure modes: too many cells, lattice becomes decoration, membranes block flow, chunk boundaries obscure the spine.
- Example: `1|1414|14|141|141414|14|11`.

### Middle-Out Gravity

- Compressed token: `MiddleOutGravity`
- Plain meaning: a decompression method that anchors on the densest/heaviest node, then radiates meaning outward to lighter neighboring chunks.
- 0x10 behavior: low gravity is a small organizing cue; mid gravity makes the densest chunk a local anchor; high gravity lets a heavy node act as the artifact's center of gravity.
- Audio: arrangement locks onto the strongest phrase, drop, hook, or pressure cell and lets surrounding moments support it.
- Image: primary gravity well governs secondary wells, seams, counterweights, and exit paths.
- Video: central event or shot determines how preceding and following shots are interpreted.
- Timbre hypothesis: the heaviest node may pull low-end, width, density, silence, or harmonic emphasis depending on semantic weight.
- Attention effect: creates orientation by finding the heaviest meaningful node first, then resolving context outward.
- Productive deviation: the model may discover a better center than the human expected if the new center strengthens the spine.
- Failure modes: wrong node becomes center, heavy chunk swallows subtle neighbors, middle-out scan ignores necessary sequence, gravity becomes intensity-only.
- Example: `Find 141414 as the dense node, then decompress outward through 1|1414|14|141|141414|14|11.`
