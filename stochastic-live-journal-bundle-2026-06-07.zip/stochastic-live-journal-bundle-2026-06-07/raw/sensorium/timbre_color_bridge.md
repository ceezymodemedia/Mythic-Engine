# Timbre and Color Bridge

This note holds the first research lane for connecting color cards to sound.

The aim is not to force universal synesthesia. Human color-sound mappings vary. The aim is to give the Sensorium measurable hypotheses that can be revised by listening, generation results, and analyzer evidence.

## Starting Claim

Color words in a prompt often behave like timbre instructions.

They can imply:

- brightness
- register
- spectral density
- attack shape
- decay behavior
- harmonicity or dissonance
- texture/noise ratio
- warmth/coolness
- saturation/distortion
- spatial depth

This gives color cards a bridge into SonicMetrix.

## Proposed Audio Axes

| Visual/Tactile Term | Possible Audio Proxy | Notes |
| --- | --- | --- |
| brightness | spectral centroid, high-band energy | Yellow/white often rise here, black/ashen often lower it. |
| warmth | low-mid energy, consonance, soft saturation | Gold/orange/purple may carry warmth differently. |
| saturation | harmonic density, distortion, compression | Red/orange can saturate aggressively; gold can saturate gently. |
| opacity | reverb density, low-pass behavior, masking | Black/purple/ashen may obscure detail intentionally. |
| edge | transient strength, attack slope, high-mid bite | Red/yellow/triangle/warning often sharpen edge. |
| glow | sustained harmonics, decay, soft reverb | Gold/glow/resonance should linger rather than jab. |
| residue | noise floor, tape hiss, dry decay | Ashen/tar/smoke/sludge live here. |
| gravity | sub/low band energy, slow tempo, low centroid | Black/crown/pressure/heavy should not be scored as weak just because they are quiet. |
| fever | modulation, detune, instability, high-mid agitation | Yellow/green/red can become fever through instability. |
| breath | silence ratio, air band, soft transient onset | White/respite/absence can still be high effort. |

## First Color-to-Timbre Hypotheses

### Gold

Gold should sound bright but not brittle. It wants upper harmonic sheen, chimes, bells, warm brass, soft choir, or glowing pads. It should usually reduce harshness unless paired with corrupting cards like `Tarnish`, `Rot`, or `Verdict`.

### Red

Red should increase urgency. It may sharpen attacks, raise transient density, add distortion, push drums forward, or make the voice more edged. Restrained red should be scored as valid if the threat becomes cold pressure rather than volume.

### Green

Green is unstable because it can mean life or poison. In sound, it may become wet modulation, low-mid organic density, detuned pads, nasal reeds, or slow spread. The analyzer should look for texture and motion, not only loudness.

### Yellow

Yellow should often become signal. It can be whistle, bell, tick, high-mid pulse, feverish synth, hazard brightness, or brittle percussion. Yellow may be small but attention-grabbing.

### Orange

Orange is kinetic warmth. It should often move the body: groove, percussion, embered organ, low brass, heat shimmer. It can be less alarming than red and less sacred than gold.

### Black

Black should not be treated as absent by default. It can be active negative space: sub pressure, deep reverb, silence pressure, low drones, low spectral centroid, or swallowed detail.

### White

White can be breath, exposure, air, choir, static wash, sterile piano, or erasure. High white can be overwhelming even without density if it removes texture or hiding places.

### Purple

Purple tends toward nocturne: low-mid richness, velvet reverb, smoky sax, dark strings, lush pads, baritone weight. It can carry power, bruise, or mysticism depending on paired cards.

### Ashen

Ashen should sound post-event: dry, dusty, filtered, hissed, raspy, low-sustain, desaturated. It is residue rather than climax.

## Analyzer Implication

The future audio analyzer should keep a `color_timbre_fit` lane separate from raw intensity.

Example:

```text
Prompt card: Black
Expected timbre: low centroid, sub pressure, active silence, deep reverb
Observed intensity: 3.2
Color/timbre fit: strong
Interpretation: this is not underperformance; black is acting as gravity.
```

## First Human Research Assignment

For each color, collect a few example instruments, registers, or production behaviors that feel naturally aligned.

Suggested starting grid:

| Color | Instrument Families | Register | Texture | Emotional Direction |
| --- | --- | --- | --- | --- |
| Gold | bells, brass, choir, warm pads | mid-high | luminous sustain | worth, mercy, coronation |
| Red | drums, brass stabs, distorted guitar, shouted vocal | mid-high | sharp/saturated | wound, alarm, heat |
| Green | reeds, detuned pads, wet synth, bowed textures | low-mid/mid | organic/wet | growth, envy, poison |
| Yellow | whistles, ticks, small bells, brittle synth | high-mid/high | thin/bright | warning, fever, signal |
| Orange | percussion, organ, low brass, groove bass | low-mid/mid | warm/kinetic | ember, appetite, motion |
| Black | sub bass, drones, low strings, deep reverb | low/sub | dense/voided | concealment, gravity |
| White | choir breath, noise wash, sparse piano, airy strings | high/air | clean/exposed | clearing, erasure |
| Purple | sax, dark strings, baritone, lush pads | low-mid | velvet/smoky | royalty, bruise, nocturne |
| Ashen | tape hiss, worn piano, dry percussion, rasp | mid/low-mid | dusty/dry | aftermath, residue |

