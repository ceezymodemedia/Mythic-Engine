# Initial Cross-Modal Test Prompts

These prompts are designed to test whether compressed card clusters produce stable behavior across sound, image, and video.

## Pair 1: Gentle / Warning

### A

```text
Gold Harmony Respite Glow Resonance
```

Expected behavior:

- soft radiance
- lowered friction
- warm upper harmonics or visible glow
- recovery after pressure
- lingering after-feeling

### B

```text
Red Triangle Canary Warning
```

Expected behavior:

- pointed danger
- high-salience signal
- warning before consequence
- sharper attack or visual edge
- attention routed toward threat

## Pair 2: Growth / Judgment

### A

```text
Green Sludge Spiral Containment
```

Expected behavior:

- living or toxic spread
- recursive pull
- wet/organic texture
- motion held inside boundaries
- beauty and threat coexisting

### B

```text
Black Glass Silence Verdict
```

Expected behavior:

- active negative space
- reflective hardness
- quiet finality
- exposed judgment
- silence after decision

## Pair 3: Energy Chain

```text
Burst Spark Ignition Erupt
```

Expected behavior:

- pressure released in stages
- tiny start becoming committed motion
- clear threshold between spark and ignition
- eruption as consequence, not just loudness

## Pair 4: Aftermath

```text
Ashen Smoke Aftermath Choir
```

Expected behavior:

- post-event residue
- dry or filtered texture
- soft collective grief
- evidence after fire
- beauty without full restoration

## Scoring Questions

For each generation, ask:

- Did the output become the world described?
- Did color behave as atmosphere, timbre, and attention signal?
- Did the most important event match applied effort, not just loudness or brightness?
- Did any accident deepen the artifact?
- Did the model transform compressed words into performance behavior?

