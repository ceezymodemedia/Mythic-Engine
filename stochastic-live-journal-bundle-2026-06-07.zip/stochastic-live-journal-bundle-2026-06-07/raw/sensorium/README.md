# Stochastic Sensorium

Stochastic Sensorium is the proposed larger home for the SonicMetrix work.

SonicMetrix remains the audio analysis/player module. The Sensorium names the broader instrument: a pilotable ecosystem for translating compressed 0x10 framework intent into measurable media behavior across sound, image, video, motion, color, text, and attention.

## Working Thesis

The project is no longer only asking whether a song obeyed a prompt.

It is asking:

```text
What does generated media reveal when it uses the framework back at us?
```

The Sensorium treats prompts, generated outputs, human listening/viewing notes, analyzer records, and compressed cards as one refinement loop:

```text
Intent -> Generation -> Experience -> Measurement -> Interpretation -> Deck Revision -> Better Intent
```

## Module Map

- `SonicMetrix`: audio analysis, playback, temporal maps, 0x10 effort curves, semantic atmosphere scoring.
- `VisualMetrix`: proposed image-composition analyzer for color, shape, spatial pressure, visual attention, and semantic embodiment.
- `MotionMetrix`: proposed video analyzer for temporal attention, scene pressure, motion arcs, cuts, persistence, and event rhythm.
- `0x10 Decks`: reusable compressed meaning cards that keep prompt compression reversible and auditable.
- `Pilot Console`: proposed AI-facing interface for using collected metadata to steer new media generation.

## Core Principle

Compressed language is useful only when it remains interpretable.

Each compressed token should have a card face and a card back:

- Face: compact token usable in prompts, schemas, or controls.
- Back: meaning, behavior, modality mappings, expected evidence, productive deviations, and failure modes.

This lets an AI pilot the app through compressed symbols without forcing humans to lose the trail of meaning.

## Four Counts, Generalized

The Four Counts frame from the listening map becomes modality-neutral:

| Domain | Count 1 | Count 2 | Count 3 | Count 4 |
| --- | --- | --- | --- | --- |
| Song | Textual Count | Vocal Count | Sonic Count | Attention Count |
| Image | Prompt Count | Object/Form Count | Color/Spatial Count | Attention Count |
| Video | Script/Shot Count | Motion Count | Sound/Visual Count | Attention Count |
| Deck | Token Count | Card Count | Relationship Count | Attention Count |

The goal is not to make every count equal. The goal is to notice where meaning expands, compresses, mutates, or becomes memorable.

## Accident Aperture

Not all incoherence is error.

The Sensorium should preserve meaningful accidents long enough to ask whether they deepen the artifact. A visual flaw, vocal crack, strange color migration, static scar, or unexpected phrasing can become framework evidence if it supports the spine.

```text
Keep it if the scar strengthens the spine.
Remove it if it only creates noise.
```

