# Compression Blades Integration Note

This note adapts the Ceezyan Blade compression method into the Stochastic Sensorium project.

## Why It Matters

The Sensorium needs to compress large conceptual artifacts without flattening their meaning.

The Compression Blade method gives the project a practical rule:

```text
Preserve before trimming. Trim before condensing.
```

This matters because SonicMetrix and the wider Sensorium often handle source material that contains:

- exact 0x10 schemas
- prompt structures
- lyric examples
- analyzer scores
- failure modes
- model-behavior observations
- emotional or aesthetic texture
- source-critical definitions

Those should not all be compressed the same way.

## 3x7 Blade

The three passes:

1. Preserve
   - Protect source-critical material.
   - Use for formulas, numeric schemas, exact prompt syntax, exact lyrics, code, citations, and definitions.

2. Trim
   - Reduce phrase-level excess while keeping readable meaning.
   - Prefer this for most notes, summaries, and deck entries.

3. Condense
   - Apply letter-level compression only after semantic meaning and structure are safe.
   - Use when character limits matter, such as Suno style boxes.

The seven facets:

1. Meaning: what must remain true.
2. Mechanism: how the concept works.
3. Scale: what numbers, ranges, proportions, or intensities matter.
4. Constraint: what limits, warnings, or failure modes matter.
5. Affect: what emotional or aesthetic signal matters.
6. Agency: what the user, AI, model, persona, or system may do.
7. Anchor: where the meaning attaches to the source.

## Semantic Companion Layer

Cards should not absorb everything.

When the compressed card needs exact supporting material, it should point to a companion layer.

Use companion layers for:

- equations
- code
- proofs
- exact prompt schemas
- lyrics
- unusual syntax
- numeric 0-10 or 0x10 sequences
- analysis records
- anything where paraphrase would damage evidence

This gives the deck two bodies:

```text
Card = compact pilotable meaning
Companion = source-preserving evidence body
```

## Root Word Layer

Every compressed deck should expose root words so smaller models do not have to infer the whole vocabulary from compressed shards.

For each deck, preserve:

- high-signal source terms
- aliases
- abbreviations
- reconstruction cues
- local dictionary entries

Example:

```text
Gold -> worth, warmth, illumination, coronation, harmonic release
Ashen -> residue, aftermath, dust, exhausted texture, evidence after fire
Verdict -> judgment, finality, naming, closure, silence after decision
```

## 5x10 Counter Layer

The 5x10 counter prevents overcompression.

Each card or source chunk can be scored from 0-10 across:

1. Semantic density
2. Emotional density
3. Procedural density
4. Tether need
5. Compression risk

Rules:

- High semantic density: preserve definitions and exact claims.
- High emotional density: preserve texture and affective language.
- High procedural density: preserve sequence/order.
- High tether need: link to companion material.
- High compression risk: prefer readable compactness over letter-level compression.

## Deck Application

For Sensorium cards:

```text
Card face: compressed token
Card back: readable meaning
Companion: exact source material or evidence
Root words: reconstruction vocabulary
5x10 counter: compression safety profile
```

## Analyzer Application

Analyzer summaries should separate:

- measured data
- inferred interpretation
- human listening/viewing notes
- source-critical prompt/lyric text
- compressed card references

This keeps SonicMetrix evidence usable by both humans and smaller models.

## Codebase Lens

Future modules should make their compression role visible:

- what they preserve
- what they trim
- what they condense
- what they refuse to compress
- what layer they belong to
- what model floor they serve

The app should not become an AI. It should become a structured context engine that lets an AI pilot creative media through dense, auditable meaning.

