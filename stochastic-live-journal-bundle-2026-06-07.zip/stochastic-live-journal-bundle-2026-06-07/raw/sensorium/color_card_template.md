# Color Card Template

Use this when building color cards for the Stochastic Sensorium.

Color clusters like `ivory / stone / ash` are useful. They let one card family hold related shades while still preserving meaningful differences.

## Fast Version

```text
Color Family:
Core Shades:
Plain Meaning:
Emotional Direction:
Material / Texture:
Light Behavior:
Sound / Timbre:
0x10 Low:
0x10 Mid:
0x10 High:
Good Pairings:
Danger Pairings:
Failure Modes:
Example Prompt:
Notes:
```

## Filled Example

```text
Color Family:
Ivory / Stone / Ash

Core Shades:
ivory, bone, chalk, stone, ash, smoke-white, dust-gray

Plain Meaning:
memory after heat; pale survival; sacred residue; something once alive or burning, now quiet

Emotional Direction:
grief, witness, exhaustion, reverence, aftermath, restrained mercy

Material / Texture:
porous stone, old paper, bone, powder, cooled soot, dry dust

Light Behavior:
matte, low-glare, soft reflection, candle-touched edges

Sound / Timbre:
worn piano, dry strings, breath noise, tape hiss, muted choir, low-sustain percussion

0x10 Low:
a faint dusting; breath on old paper; soft residue at the edge of attention

0x10 Mid:
clear aftermath; the room feels drained but meaningful; dry texture becomes audible/visible

0x10 High:
post-disaster sacredness; ash becomes identity; the whole field feels like evidence after fire

Good Pairings:
resonance, memory, parchment, choir, candle, verdict, breath, stillness

Danger Pairings:
red, rust, black, fracture, static, erasure

Failure Modes:
bland gray, empty minimalism, under-signaled emotion, lifeless desaturation

Example Prompt:
Ivory Stone Ash Memory Choir

Notes:
This family should not feel clean like white. It should feel used, touched, burned, remembered.
```

## Full Version

Use the full version when a color feels important enough to become part of the main deck.

```yaml
id:
color_family:
compressed_token:
core_shades:
plain_language:
core_meaning:
emotional_direction:
material_texture:
light_behavior:
0x10_behavior:
  low_register:
  mid_register:
  high_register:
  note:
audio_signature:
  instrument_families:
  register:
  spectral_behavior:
  attack_decay:
  production_texture:
image_signature:
  palette_behavior:
  spatial_behavior:
  object_affinities:
video_signature:
  motion_behavior:
  transition_behavior:
  scene_behavior:
attention_effect:
good_pairings:
danger_pairings:
productive_deviation:
failure_modes:
example_prompt_use:
research_notes:
```

## Color Family Guidance

### 1. Cluster By Meaning, Not Just Hue

Good:

```text
ivory / stone / ash
```

These belong together because they share residue, age, dryness, and aftermath.

Also good:

```text
indigo / midnight / deep blue
```

These share depth, night, cold interiority, distance, and submerged attention.

Also good:

```text
gold / seam-light
```

This is more symbolic than hue-based, but it is strong because it connects color to function: gold as the light that reveals where the seam holds.

### 2. Separate Neighbors When Their Behavior Changes

Yellow and gold should usually be separate.

Yellow often signals:

```text
warning, fever, signal, glare, candle, hazard
```

Gold often signals:

```text
worth, mercy, sacred warmth, coronation, harmonic release
```

They can overlap visually, but they do different work.

### 3. Give Each Color A Timbre Guess

Even rough guesses help.

Examples:

```text
Gold: bells, warm brass, soft choir, glowing pads
Ash: tape hiss, dry piano, rasp, low-sustain percussion
Indigo: low strings, distant synth, soft sub, midnight reverb
Red: sharp drums, brass stabs, distorted guitar, edged vocal
```

### 4. Include Failure Modes

Failure modes are important because they teach the analyzer what not to reward.

Examples:

```text
Gold failure: cheap luxury, generic yellow, false triumph
Ash failure: bland gray, lifeless desaturation
Red failure: melodrama, panic without consequence
Blue failure: generic sadness, inactive coolness
```

## Tiny Fill-In Card

Use this if you want to move quickly.

```text
[color family]

means:
feels like:
looks like:
sounds like:
moves like:
low 0x10:
mid 0x10:
high 0x10:
pairs with:
breaks when:
example:
```

