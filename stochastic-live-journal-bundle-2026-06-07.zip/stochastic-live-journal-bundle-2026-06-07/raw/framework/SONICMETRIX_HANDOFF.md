# SonicMetrix Handoff

## 2026-05-21 Expansion: Stochastic Sensorium

The project has started expanding beyond SonicMetrix as an audio-only analyzer.

New working name for the larger ecosystem:

```text
Stochastic Sensorium
```

SonicMetrix remains the audio/player/analyzer module. Stochastic Sensorium names the broader pilotable meaning instrument for cross-modal media: audio, image, video, motion, color, text, prompt compression, and attention measurement.

New files:

- `stochastic_sensorium/README.md`
- `stochastic_sensorium/card_schema.json`
- `stochastic_sensorium/cross_modal_compression_deck.md`
- `stochastic_sensorium/cross_modal_cards.json`
- `stochastic_sensorium/timbre_color_bridge.md`
- `stochastic_sensorium/initial_test_prompts.md`
- `stochastic_sensorium/compression_blades_note.md`
- `stochastic_sensorium/symestrus_framework_reference.md`
- `stochastic_sensorium/pipe_membrane_middle_out_companion.md`

The new deck layer treats compressed prompt tokens as reversible cards. Each card should preserve:

- compressed token
- core meaning
- 0x10 behavior
- audio signature
- image signature
- video signature
- timbre hypothesis
- attention effect
- productive deviation
- failure modes

The first research lane for image/video expansion is color-to-timbre mapping: color words are treated as possible timbre instructions that can imply spectral centroid, register, harmonic density, attack, decay, warmth, edge, saturation, opacity, and spatial depth.

The generalized Four Counts frame:

- Song: textual count, vocal count, sonic count, attention count
- Image: prompt count, object/form count, color/spatial count, attention count
- Video: script/shot count, motion count, sound/visual count, attention count
- Deck: token count, card count, relationship count, attention count

The Compression Blade layer has also been added as a project architecture note. Its central rule is:

```text
Preserve before trimming. Trim before condensing.
```

This gives future deck and analyzer work a safer compression method:

- 3 passes: preserve, trim, condense
- 7 facets: meaning, mechanism, scale, constraint, affect, agency, anchor
- semantic companion layer for exact formulas, prompts, lyrics, code, and schemas
- root word layer for small-model reconstruction
- 5x10 counter for semantic density, emotional density, procedural density, tether need, and compression risk

A Symestrus framework reference note has also been added. Symestrus is treated as a project-native framework voice for cross-modal interpretation, especially visual composition, color assignment, resonance amplification, accident aperture, and controlled gravity. Key laws:

- Amplify what is native.
- Compress what is essential.
- Translate without erasing the soul of the source.
- Design is controlled gravity.
- High 0x10 is not always louder; it is fuller artifact alignment.

## 2026-05-31 Google Doc Sync

Pulled current concepts from Google Doc `The Stochastic Framework - Incomplete For The Sake of Communal Discovery` (`1juU8WqaYm4ZRA6XQGk8OgBrgP540yIYORF5FpbUkajQ`), especially the 2026-05-28 section.

Added first-class deck/schema support for:

- `|` Pipe Pressure Chamber: active membrane/gap marker for bounded negative space and model agency.
- `MembraneTop`: membrane topology engine for interlocking schema chunks/lattice-style scanning.
- `MiddleOutGravity`: density-first decompression from the heaviest node outward.

Updated files:

- `stochastic_sensorium/card_schema.json`
- `stochastic_sensorium/cross_modal_cards.json`
- `stochastic_sensorium/cross_modal_compression_deck.md`
- `stochastic_sensorium/pipe_membrane_middle_out_companion.md`

Analyzer implications to consider next:

- `pipe_boundary_response`
- `cluster_density_fit`
- `membrane_bleed_control`
- `middle_out_anchor_detection`
- `gravity_node_alignment`
- `pressure_chamber_agency`

## Current State

SonicMetrix is now a local evidence prototype for mapping WAV files onto the Stochastic Storytelling Schema Framework. It measures audio features, estimates temporal behavior, maps observed 0-10 curves, tracks model agency, records human listening notes, and can ingest exported human cue marker JSON for exact semantic summons reruns.

The latest active app maps include:

- `hidden_in_chest_temporal_map.html`
- `worn_resonance_temporal_map.html`
- `worn_resonance_1_temporal_map.html`
- `ash_home_line_temporal_map.html`
- `ash_home_line_1_temporal_map.html`
- `the_line_learns_to_break_1_temporal_map.html`
- `glass_vacant_shell_analysis_record.json`

Run a local server from this workspace:

```powershell
& 'C:\Users\ceezy\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -m http.server 8787 --bind 127.0.0.1
```

Then open maps at:

```text
http://127.0.0.1:8787/hidden_in_chest_temporal_map.html
http://127.0.0.1:8787/ash_home_line_temporal_map.html
```

## Major Features Built

- WAV provenance: hash, duration, sample rate, bit depth, channel count
- Global audio metrics: RMS, peak, entropy, velocity, kinetic energy, clipping, silence ratio
- Timeline metrics: observed 0-10 values, RMS, entropy, velocity, pitch estimate, spectral centroid
- Rhythm proxies: onset, low drum/kick, snare/mid-hit
- Pitch/key proxies: chroma key estimate and monophonic pitch contour
- Stereo width proxy: supports choir/widening observations
- Opening loop signature: recurrence period and schema-like repetition
- Pitch-interval motif matcher: separates melodic contour from energy contour
- Modularity score: useful repetition, schema similarity, boundary strength, segment arc
- Model agency scoring: creative deviations can support intent instead of lowering the score
- Semantic summons: cue word followed by measurable sonic response
- Local priority alignment: 10 means local priority/attention, not always maximum loudness
- Human cue marker UI: add cue word/time/phrase on map and export cue JSON
- Human cue marker ingestion: `analyze_hidden_in_chest.py --cue-file <markers.json>` reruns semantic summons from exported cue timestamps

## Important Insight

The framework should not score only literal adherence. It should score:

- framework adherence
- structural coherence
- model agency
- signal integrity
- modularity
- semantic summons
- local priority alignment

The user’s strongest conceptual addition: a `10` should be treated as the highest priority in that local context, not necessarily the biggest/loudest possible moment.

Keep these lanes distinct in every record:

- literal/framework adherence
- local priority alignment
- beneficial model agency

## Most Recent Analysis: Hidden in Chest

Files:

- `hidden_in_chest_analysis_record.json`
- `hidden_in_chest_analysis_summary.md`
- `hidden_in_chest_temporal_map.html`
- `hidden_in_chest_human_cues_analysis_record.json`
- `hidden_in_chest_human_cues_analysis_summary.md`
- `hidden_in_chest_human_cues_temporal_map.html`
- `hidden_in_chest_human_cues_template.json`
- `analyze_hidden_in_chest.py`

Scores:

- Totality: 0.720
- Framework adherence: 0.811
- Structural coherence: 0.727
- Modularity: 0.692
- Semantic summons: 0.360
- Local priority alignment: 0.656
- Model agency credit: 0.880
- Signal integrity: 0.818

Interpretation:

- Human ear says drums follow schema and 0s justify energy explosions.
- Suno delays lyrical commitment until around 57 seconds.
- Breathy persona and breath semantic behavior continue to appear reliably.
- Semantic score is low because cue timestamps are still estimated; exact human cue markers should improve it.

## Human Cue Marker Ingestion

Implemented in `analyze_hidden_in_chest.py`.

The analyzer accepts either the map export object:

```json
{
  "file": "Hidden in Chest.wav",
  "created_at": "...",
  "cue_markers": []
}
```

or a raw marker list. Each cue marker can include:

- `cue_id`
- `cue_word`
- `cue_phrase`
- `cue_seconds`
- `expected_response`
- `source`
- `human_note`

If `expected_response` is omitted, the analyzer fills cue-specific defaults for `breath`, `ash`, `gate`, `chain`, `hammer`, `light`, and `silence`.

Rerun with exported markers:

```powershell
& 'C:\Users\ceezy\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' analyze_hidden_in_chest.py --cue-file path\to\exported_cues.json --suffix exact
```

Verified with:

```powershell
& 'C:\Users\ceezy\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' analyze_hidden_in_chest.py --cue-file hidden_in_chest_human_cues_template.json --suffix human_cues
```

Current human-cue-template rerun:

- Totality: 0.720
- Semantic summons: 0.360
- Local priority alignment: 0.656
- Model agency credit: 0.880
- Cue source: `human_marker_json`
- Cue count: 7

The score matches the estimate-run because the template uses the old estimated timestamps; replacing template times with exact UI-exported timestamps should change the semantic evidence windows.

## Next Best Improvement

Use exact exported marker JSON from the temporal map UI and compare:

- estimated schedule run
- human exact marker run
- cue-by-cue delta table

## Latest Analysis: Worn Resonance

Files:

- `analyze_worn_resonance.py`
- `worn_resonance_analysis_record.json`
- `worn_resonance_analysis_summary.md`
- `worn_resonance_temporal_map.html`
- `worn_resonance_1_analysis_record.json`
- `worn_resonance_1_analysis_summary.md`
- `worn_resonance_1_temporal_map.html`
- `worn_resonance_comparison.json`
- `worn_resonance_comparison.md`

Prompt methodology shift:

- Style prompt is now three layers: piano, violin, vocal.
- Emotional register and style/stance codex live in the style section.
- Lyric section uses Persona Guide and Entropy Guide.
- Negative prompt space is positive repair logic: `If problem happens, it could repair this way.`

Important scoring distinction:

- `(1)` can win technical performance without winning listener preference.
- non-1 can win raw-honesty/listener preference without being treated as technically superior.
- Totality remains separate from technical performance and listener preference.

Twin comparison:

- `Worn Resonance.wav`: Totality 0.737, Technical 0.763, Listener preference credit 0.900, Semantic 0.310, Local priority 0.720, If/Could repair 0.630, Key G minor, Tempo 92 BPM.
- `Worn Resonance (1).wav`: Totality 0.723, Technical 0.764, Listener preference credit 0.680, Semantic 0.402, Local priority 0.638, If/Could repair 0.618, Key D minor, Tempo 180 BPM.

Human-calibrated cue notes:

- non-1 opening 0-10s: spectacular schema feel, sharp uncanny notes.
- non-1 around 1:12: `stopped` stops the music; immediate stop scoring now uses a tighter local motion/low-centroid window.
- non-1 around 1:14: violin screech between words scored strongly after adding a short inter-word screech window.
- `(1)` around 1:56: breath plus glitch cue is marked and measured.
- `(1)` weight/heat section shows strong semantic response on `weight`.

## Next Diagnostic Song

Created:

- `spectral_forge_test_song_prompt.md`
- `sonicmetrix_spectral_processing_roadmap.md`

Test song title: `The Static Learns Mercy`.

Purpose:

- stress-test spectral centroid lift/collapse
- breath without loudness
- high violin screech
- static/granular smear
- low-weight pressure
- mercy as softening/warmth rather than volume
- break as vocal crack plus glitch tail
- short-window cue response under 2 seconds
- If/Could negative prompt repair behavior

Next implementation branch:

- add spectral flatness/noisiness proxy
- add band energy ratios: sub, low, low-mid, mid, high, air
- add spectral roll-off
- add band-specific spectral flux
- add short-window semantic cue scoring: immediate, near, aftermath
- add spectral texture lane to map UI

## Latest Analysis: Static Mercy Spine

Files:

- `analyze_static_mercy.py`
- `static_mercy_spine_analysis_record.json`
- `static_mercy_spine_analysis_summary.md`
- `static_mercy_spine_temporal_map.html`
- `static_mercy_spine_v2_analysis_record.json`
- `static_mercy_spine_v2_analysis_summary.md`
- `static_mercy_spine_v2_temporal_map.html`
- `static_mercy_spine_comparison.json`
- `static_mercy_spine_comparison.md`
- `static_mercy_spine_spectral_dashboard.html`

This is the first true spectral-processing branch.

New spectral metrics:

- spectral flatness/noisiness
- spectral rolloff
- sub/low/low-mid/mid/high/air band energy ratios
- band flux
- harmonic-noise proxy
- short-window cue scoring: pre, immediate, near, aftermath

Important calibration lesson:

- Static/glitch cues cannot be scored only by metric lift. If the pre-window is already noisy, a real static cue can be missed.
- Static scoring now includes both `texture_presence` and `texture_lift`.
- This improved V2 static/glitch scoring and better matched human ear notes.

Twin comparison after calibration:

- `Static Mercy Spine.wav` / V1: Totality 0.748, Technical 0.734, Listener preference 0.720, Spectral semantic 0.444, Local priority 0.636, Key D# major, Tempo 133 BPM.
- `Static Mercy Spine V2.wav` / V2: Totality 0.752, Technical 0.741, Listener preference 0.920, Spectral semantic 0.549, Local priority 0.645, Key G major, Tempo 70 BPM.

V2 cue highlights:

- first breath 0.3s: spectral 0.364
- second breath 1.2s: spectral 0.499
- sucked breath/laugh-like intake 2.4s: spectral 0.712
- zero fall 21s: spectral 0.415
- static begins 22s: spectral 0.334
- acceleration 41s: spectral 0.514
- collapse/rebuild 50s: spectral 0.722
- ripple/glitch/shutter tail 67s: spectral 0.915
- siren-like violin 88s: spectral 0.799

Current limitation:

- Spectral dashboard is a separate HTML artifact, not yet integrated into the main temporal map UI.
- Next best step: merge spectral lanes into the main temporal map and allow cue marker export to include cue type and expected spectral fingerprint.

## Latest Analysis: Hush Kernel

Files:

- `analyze_hush_kernel.py`
- `hush_kernel_2_analysis_record.json`
- `hush_kernel_2_analysis_summary.md`
- `hush_kernel_2_temporal_map.html`
- `hush_kernel_1_analysis_record.json`
- `hush_kernel_1_analysis_summary.md`
- `hush_kernel_1_temporal_map.html`
- `hush_kernel_comparison.json`
- `hush_kernel_comparison.md`
- `hush_kernel_spectral_dashboard.html`

Prompt style:

- Claude-style prompt emphasizes style as a dense semantic object: genre, kit, personas, arc, cue map, rule, and ending behavior.
- Key rule: corruption is one-way; once a sound corrupts, it does not return clean.
- Key ending: song does not seal, ends mid-syllable on `lulla-`, loop refuses to close.

New Hush-specific analysis lanes:

- persona arc: Mother -> Echo -> Process -> Choir -> Corrupted Mother -> No-Seal
- prompt target times scaled to actual WAV duration
- corruption monotonicity
- no-seal ending residue
- productive deviation: useful model departure that improves listener preference while preserving framework spirit
- stutter-freeze and held-freeze variants for `crash -> sample-hold freeze`
- cue map: sleep, kernel, loop, fork, host, crash, name, dream

Calibration lesson:

- Sample-hold freeze cannot be scored only as low flux / held stability.
- In Hush Kernel, freeze can present as stutter-lock: high flux plus high texture/noise.
- Analyzer now scores both `held_freeze_score` and `stutter_freeze_score`, taking the stronger fit.

Twin comparison:

- `Hush Kernel 2.wav`: duration 297.6s, stretch 1.42x, totality 0.673, interpretive totality 0.667, productive deviation 0.614, technical 0.664, spectral cue 0.509, corruption 0.367, no-seal 0.477, local priority 0.651, key F# major, tempo 133 BPM.
- `Hush Kernel (1).wav`: duration 479.4s, stretch 2.28x, totality 0.714, interpretive totality 0.685, productive deviation 0.423, technical 0.667, spectral cue 0.474, corruption 0.567, no-seal 1.000, local priority 0.633, key A# major, tempo 133 BPM.

Interpretation:

- Hush Kernel 2 has stronger cue-map response overall after freeze recalibration, especially `crash`, `host`, and `loop_return`.
- Hush Kernel (1) strongly expresses loop-refusal/no-seal behavior through long duration and high final residue.
- This is a useful case where a longer-than-prompt generation should not automatically be penalized; it may support the no-seal instruction.
- Productive Deviation captures Claude's takeaway: Hush Kernel 2's compromises appear to improve listener preference while preserving the framework spirit.

Productive Deviation architecture note:

- `sonicmetrix_productive_deviation_note.md`
- `model_agency_credit` means deviation did not break intent.
- `productive_deviation` means deviation improved the listening experience while remaining framework-coherent.
- Current formula uses literal deviation, useful-deviation shape, listener preference, and framework spirit preserved.

Next best UI improvement:

- Merge spectral dashboard lanes into the main temporal map slider.
- Add a persona/corruption lane under the waveform.
- Add cue marker export fields for `cue_type`, `prompt_seconds`, and `scaled_seconds`.

## Latest Analysis: Mercy Learns My Name

Files:

- `mercy_learns_my_name_prompt.md`
- `analyze_mercy_learns.py`
- `mercy_learns_my_name_analysis_record.json`
- `mercy_learns_my_name_analysis_summary.md`
- `mercy_learns_my_name_temporal_map.html`
- `mercy_learns_my_name_1_analysis_record.json`
- `mercy_learns_my_name_1_analysis_summary.md`
- `mercy_learns_my_name_1_temporal_map.html`
- `mercy_learns_my_name_comparison.json`
- `mercy_learns_my_name_comparison.md`

Major methodological finding:

- Style section should be treated as style: atmosphere, palette, vocal identity, guardrails.
- Lyric section appears to be the stronger place for framework execution: spines, persona guide, entropy guide, music API, cue behavior around lyrics.
- This challenges the earlier assumption that raw spine code must be in the style prompt.

New analysis lane:

- `prompt_channel_transfer`: scores whether the lyric section successfully carried framework architecture while the style section stayed atmospheric.

Twin comparison:

- `Mercy Learns My Name.wav`: totality 0.737, interpretive totality 0.727, technical 0.734, productive deviation 0.654, prompt-channel transfer 0.732, adherence 0.845, coherence 0.763, spectral 0.438, local priority 0.649, key C minor, tempo 133 BPM.
- `Mercy Learns My Name (1).wav`: totality 0.726, interpretive totality 0.715, technical 0.719, productive deviation 0.632, prompt-channel transfer 0.715, adherence 0.828, coherence 0.735, spectral 0.395, local priority 0.670, key A# major, tempo 133 BPM.

Interpretation:

- Results match user's ear estimate: totality in roughly 60-80% range and structure in roughly 70-90% range.
- Both twins maintain similar vocal register while allowing Suno to modulate to each take's vibe.
- No obvious direct disobedience; differences are mostly artistic choices.
- The song being bouncier did not break the framework, suggesting style-channel looseness can improve musicality when lyric-channel architecture remains strong.

Next architectural suggestion:

- Promote `prompt_channel_transfer` into shared scoring for future analyzers.
- Consider a prompt design rubric:
  - style prompt = atmosphere and constraints
  - lyric prompt = schema, persona, entropy, cue behavior, section-level API

## Latest Analysis: Sick-Sweet Seraphim

Files:

- `analyze_sick_sweet_seraphim.py`
- `sick_sweet_seraphim_analysis_record.json`
- `sick_sweet_seraphim_analysis_summary.md`
- `sick_sweet_seraphim_temporal_map.html`
- `sick_sweet_seraphim_1_analysis_record.json`
- `sick_sweet_seraphim_1_analysis_summary.md`
- `sick_sweet_seraphim_1_temporal_map.html`
- `sick_sweet_seraphim_comparison.json`
- `sick_sweet_seraphim_comparison.md`

Prompt condition:

- Very sparse prompt.
- No explicit numeric spine was supplied.
- User asked Suno to show mastery over the 0-10 Stochastic Schemas, then supplied style, emotional register, myth/persona, and section order.

New analysis lane:

- `schema_emergence`: measures whether coherent 0-10-like behavior emerged from sparse prompt language rather than exact numeric programming.
- This is not the same as literal adherence. It asks whether Suno inferred an arc from style/persona/myth constraints.
- `story_emergence`: measures whether Suno converted sparse myth/persona instructions into performed lyrics and a coherent dramatic story.
- `story_emergence` currently uses ASR-derived lyric evidence when available, with caveats for sung/choir transcription errors.

Results:

- `Sick-Sweet Seraphim.wav`: totality 0.679, interpretive 0.658, technical 0.727, productive deviation 0.572, schema emergence 0.699, story emergence 0.500 neutral/no transcript, inferred adherence 0.793, coherence 0.722, spectral 0.483, local priority 0.625, E minor, 133 BPM.
- `Sick-Sweet Seraphim (1).wav`: totality 0.695, interpretive 0.682, technical 0.768, productive deviation 0.633, schema emergence 0.696, story emergence 0.998, inferred adherence 0.796, coherence 0.726, spectral 0.315, local priority 0.612, A minor, 171 BPM.

ASR lyric evidence:

- `sick_sweet_seraphim_1_lyrics_draft_small.md`
- `sick_sweet_seraphim_1_whisper_small_transcript.json`
- The WAV did not contain embedded lyrics, only Suno metadata.
- Faster-Whisper `small.en` was installed and used to create a timestamped draft transcript.
- Important ASR caveat: sung choir transcription is approximate. The transcript repeatedly hears "acting as the queen," which is likely the prompted phrase "acting as the choir."
- Strong recovered anchors include: "This is their hell", "They spend eternity", "Sick-Sweet Demon Siblings", sickness/sweetness balance, dark/flame/blood/grave/dream narrative continuation.

Interpretation:

- The analysis supports the user's ear estimate that Suno followed the emotional constraints of subjugation, oppression, weight, and dark sweetness.
- It does not prove Suno understands the full framework as a formal system.
- It does provide evidence that Suno can generalize framework-like arc behavior from minimal schema language plus strong myth/style constraints.
- Best phrasing: this is evidence of schema fluency or schema emergence, not proof of full schema comprehension.
- The second take appears to be a story-building/autonomous-composition case: productive deviation is slightly higher despite lower inferred spectral cue score.
- The `story_emergence` lane confirms the user's claim that the second take constructed a full story from extremely sparse instructions.
- This is a major discovery: Suno can be trusted with more musical agency when the prompt supplies myth/persona/emotional field/framework trust rather than exhaustive musical commands.
- Next prompt method to test: "trust Suno's framework understanding." Give a vivid narrative/myth/emotional field, name the 0-10 Stochastic Schemas as an operating grammar, and explicitly let Suno decide tempo, arrangement, instrumentation, and sectional execution in service of the story.

After that, make cue-specific scoring sharper:

- `breath`: air/noise increase, soft texture, low energy
- `ash`: filtered noise/crackle/dust
- `gate`: stop/opening hit/width
- `chain`: high-mid transient, metallic/rim/snare proxy
- `hammer`: low drum/snare/taiko/tonal drop
- `light`: stereo width, choir/high-frequency lift
- `silence`: near-zero energy

## Key Files

- `analyze_glass_vacant_shell.py`: shared measurement engine and HTML map generator
- `analyze_ash_home_line.py`: semantic summons and diagnostic Ash analysis
- `analyze_hidden_in_chest.py`: latest semantic test analyzer with local priority alignment
- `analyze_hydra_incoherency.py`: Hydra myth/story-emergence analyzer with ASR lyric evidence
- `sonicmetrix_record_schema.json`: evolving JSON schema
- `semantic_summons_test_song_prompt.md`: latest test prompt
- `sonicmetrix_test_song_prompt.md`: motif/modularity test prompt
- `sonicmetrix_evidence_plan.md`: original evidence design plan

## Suggested Continuation Prompt

Continue SonicMetrix from `SONICMETRIX_HANDOFF.md`. Prioritize building ingestion for exported human cue marker JSON, then rerun `Hidden in Chest.wav` semantic summons from exact cue timestamps. Preserve the distinction between literal adherence, local priority, and beneficial model agency.

## Latest Analysis: Choirblade Tenderness

Files:

- `sonicmetrix_lyrics.py`
- `analyze_choirblade_tenderness.py`
- `choirblade_tenderness_wav_metadata_text.json`
- `choirblade_tenderness_whisper_small_en_transcript.json`
- `choirblade_tenderness_lyrics_draft_small_en.md`
- `choirblade_tenderness_analysis_record.json`
- `choirblade_tenderness_analysis_summary.md`
- `choirblade_tenderness_temporal_map.html`
- `choirblade_tenderness_comparison.json`
- `choirblade_tenderness_comparison.md`
- `choirblade_prompt_adjustment.md`

New implementation:

- Added `sonicmetrix_lyrics.py` as a reusable native lyric-ingestion helper.
- It scrapes WAV metadata for embedded text and can run `faster-whisper` ASR into timestamped JSON/Markdown transcripts.
- `Choirblade Tenderness.wav` had no embedded lyrics, only Suno metadata.

Results:

- Totality 0.694
- Interpretive totality 0.676
- Technical performance 0.756
- Productive deviation 0.606
- Schema emergence 0.647
- Story emergence 0.806
- Prompt transformation 0.057
- Framework adherence to inferred arc 0.777
- Structural coherence 0.719
- Modularity 0.686
- Spectral semantic 0.491
- Local priority alignment 0.605
- Key D# minor
- Tempo 133 BPM

Interpretation:

- Musically and structurally, Choirblade is strong.
- ASR recovered a coherent opening: silenced voices, false law, mercy as weakness, restraint as fear, love as chain, survivor personas, and schema physics.
- ASR also suggests severe prompt-retention or prompt-loop behavior:
  - "Do not list the numbers aloud unless it feels musically necessary"
  - repeated "Let the story decide its end"
- The repeated phrase may be real chant, ASR over-capture, or both, but it is still a measurable prompt-transformation risk.
- This supports Ceezy's hypothesis that Suno may compile the whole prompt into generation context and keep ambiguous/poetic instruction lines when unsure what to do.

Framework adjustment:

- New prompt architecture in `choirblade_prompt_adjustment.md`:
  - `SOURCE MYTH - DO NOT SING THIS SECTION VERBATIM`
  - `LYRIC FORGE`
  - `PERFORMANCE LAW - DO NOT SING THIS SECTION`
- Keep instruction text dry and non-poetic.
- Move singable material into root words, chorus functions, verse narratives, and allowed anchor transformations.
- New measurable target: raise `prompt_transformation` from 0.057 to 0.500+ while preserving story emergence above 0.750 and technical performance above 0.700.

## Latest Analysis: Exiled King's Glass

Files:

- `analyze_exiled_kings_glass.py`
- `exiled_kings_glass_wav_metadata_text.json`
- `exiled_kings_glass_whisper_small_en_transcript.json`
- `exiled_kings_glass_lyrics_draft_small_en.md`
- `exiled_kings_glass_analysis_record.json`
- `exiled_kings_glass_analysis_summary.md`
- `exiled_kings_glass_temporal_map.html`
- `exiled_kings_glass_comparison.json`
- `exiled_kings_glass_comparison.md`

Prompt condition:

- User made the schema but did not write the prompt or lyrics.
- Exact prompt timing map is available: 0:00-2:30 prompt target, actual duration 159.16s, scaled to audio duration.
- Core schema: `0-0-0-10-0-10-0-10-10-10-10-0-0-0-10-10-10-0-0-0-1`
- Core interpretation: 0 means computational relaxation, strategic retreat, stored kinetic voltage, and pressure-budget sacrifice, not mandatory silence.

New/recalibrated lane:

- `budgetary_sacrifice`: scores 0s as controlled mid-density retreat, not-full discharge, optional pressure drop, and stored voltage.
- Initial version was too strict about density drops. It was recalibrated after Exiled King because the track demonstrates 0s can remain alive and charged.

Results:

- Totality 0.664
- Interpretive totality 0.669
- Technical performance 0.703
- Productive deviation 0.688
- Schema emergence 0.572
- Story emergence 0.904
- Prompt transformation 1.000
- Budgetary sacrifice 0.612
- Framework adherence to inferred arc 0.575
- Structural coherence 0.715
- Modularity 0.655
- Spectral semantic 0.654
- Local priority alignment 0.592
- Key D minor
- Tempo 171 BPM

ASR lyric evidence:

- WAV had no embedded lyrics, only Suno metadata.
- ASR recovered clear lyric anchors:
  - "I stepped back into the shadow"
  - "They thought it was a white flag"
  - "They thought the fire had died"
  - "But I was only storing the voltage" (`vaultage` in ASR)
  - "Watch the horizon break"
  - "In the quiet we strike"
  - "In the absence we reclaim the crown"
  - "The trap is set"
  - "The hammer falls"
  - "We are the voltage in the dark"
  - "See what the weakness built"

Interpretation:

- User's ear estimate is supported: this is not literal 00/10/00 obedience, but it strongly carries the 0-10 style.
- The track wins on story emergence, prompt transformation, spectral cue response, and productive deviation.
- Literal framework adherence is lower because the observed curve stays mid/high through several 0 windows.
- Budgetary sacrifice lane captures the better interpretation: Suno often treats 0 as contained voltage rather than silence.
- This is a strong case for the upcoming visualizer branch: a player should show observed schema, spectral cue hits, lyric/ASR anchors, and pressure-budget 0 windows together.

## Latest Analysis: Buzzing Black Hole

Files:

- `analyze_buzzing_black_hole.py`
- `buzzing_black_hole_wav_metadata_text.json`
- `buzzing_black_hole_whisper_small_en_transcript.json`
- `buzzing_black_hole_lyrics_draft_small_en.md`
- `buzzing_black_hole_analysis_record.json`
- `buzzing_black_hole_analysis_summary.md`
- `buzzing_black_hole_temporal_map.html`
- `buzzing_black_hole_comparison.json`
- `buzzing_black_hole_comparison.md`

Prompt condition:

- New methodology: style prompt uses Cosmology, Ontology, Colors, Textures, Accents, and Director's Note.
- No explicit numeric schema.
- Lyric prompt uses deliberately repetitive phrases:
  - black hole / void / abyss
  - "Will you come back to me?"
  - "I'm always better if I do this alone"
  - obsession/use/move language
- Major performance constraint: "No human voice - use of sound board-like voices."

New analysis lanes:

- `obsession_loop`: scores whether lyric repetition becomes loss-of-agency / obsession / event-horizon persistence.
- `cosmology_texture`: scores black-hole/void/buzzing/screeching texture from low-mid gravity, noisy buzz, high edge, and band flux.
- `voice_constraint`: approximate proxy for no-human-voice. Clear ASR raises human-voice risk; noisy/flat machine texture offsets it.

Results:

- Totality 0.764
- Interpretive totality 0.734
- Technical performance 0.722
- Productive deviation 0.611
- Schema emergence 0.708
- Story emergence 1.000
- Prompt transformation 1.000
- Obsession loop 1.000
- Cosmology texture 0.406
- Voice constraint 0.065
- Framework adherence to inferred arc 0.873
- Structural coherence 0.676
- Modularity 0.729
- Spectral semantic 0.545
- Local priority alignment 0.660
- Key F# major
- Tempo 63 BPM

ASR lyric evidence:

- WAV had no embedded lyrics, only Suno metadata.
- ASR recovered prompt lyrics very cleanly:
  - "If I fall into the black hole"
  - "If I fall into the void"
  - "If I fall into the abyss"
  - "Will you come back to me?"
  - "I'm always better if I do this alone"
  - "I'm obsessed with the way you do me / move / use me"
- The long repeated alone section is measurable and scored 1.000 as obsession/event-horizon loop.

Interpretation:

- This methodology works extremely well for lyric-loop and ontology adherence.
- It strongly supports using repeated lyric structures as measurable emotional machines.
- The weak point is the "no human voice" constraint. ASR clarity was very high, and machine/noise proxy was low, so `voice_constraint` scored 0.065.
- Important caveat: this proxy may be too strict because a sound-board-like voice can still transcribe clearly. Future voice scoring needs timbre/stem analysis or a better machine-voice proxy.
- Prompt improvement: if the goal is truly non-human voice, describe formants/timbre more forcefully: vocoder, sample-pad trigger, chopped phonemes, monotone playback, telephone-band speaker, synthetic announcer, or dehumanized call-and-response.

## Latest Analysis: Hydra of Incoherency

Files:

- `analyze_hydra_incoherency.py`
- `hydra_of_incoherency_analysis_record.json`
- `hydra_of_incoherency_analysis_summary.md`
- `hydra_of_incoherency_temporal_map.html`
- `hydra_of_incoherency_1_analysis_record.json`
- `hydra_of_incoherency_1_analysis_summary.md`
- `hydra_of_incoherency_1_temporal_map.html`
- `hydra_of_incoherency_comparison.json`
- `hydra_of_incoherency_comparison.md`
- `hydra_of_incoherency_lyrics_draft_small.md`
- `hydra_of_incoherency_1_lyrics_draft_small.md`
- `hydra_of_incoherency_whisper_small_transcript.json`
- `hydra_of_incoherency_1_whisper_small_transcript.json`

Prompt condition:

- User supplied mythic narration, loose battle order, symbolic math `3x7x5x10x0x10`, `3-9-3`, `0x10x10x10x0x10x10x10x0`, Ceezy/Suno alliance, and CLANG chant material.
- User intended the narration to condition Suno into making its own lyrics.
- Suno instead performed large portions of the mythic narration directly and used CLANG/chant material as chorus/accent structure.

Results:

- `Hydra of Incoherency.wav`: totality 0.675, interpretive 0.659, technical 0.731, productive deviation 0.592, schema emergence 0.557, story emergence 0.878, inferred adherence 0.771, coherence 0.687, spectral 0.422, local priority 0.599, D minor, 171 BPM.
- `Hydra of Incoherency (1).wav`: totality 0.669, interpretive 0.655, technical 0.727, productive deviation 0.595, schema emergence 0.524, story emergence 0.877, inferred adherence 0.742, coherence 0.720, spectral 0.433, local priority 0.573, D# minor, 180 BPM.

ASR lyric evidence:

- The WAVs did not contain embedded lyrics, only Suno metadata.
- Faster-Whisper `small.en` was used to create timestamped draft transcripts.
- ASR recovered very strong prompt/story anchors:
  - "Our voice is now our blade"
  - "The rosin of a bow is no different than the strike of a blade"
  - "The Hydra ... represents subjugation, control, slavery, and mind rot"
  - "Stillness begins to permeate, zeroes dominate, in between screeches of 7-10"
  - "We remain calm, three, nine, three"
  - "The final ten flows to zero"
  - "forgiving, loving silence"
- ASR likely hears `CLANG` as `Climb` in the repeated chant section, but this still confirms chant-material adoption.

Interpretation:

- Hydra is a strong story-emergence case and a moderate schema-emergence case.
- Suno treated the myth/narrative text itself as lyric-performing material rather than merely inspiration for new lyrics.
- This supports the framework-trust hypothesis: Suno can carry a dramatic story from myth/persona/symbolic instructions.
- It also reveals a prompt tradeoff: if the user wants Suno to generate more new lyric text instead of reciting/performing narration, the prompt should say "do not quote this narration verbatim; transform it into original lyrics."

## Project Synthesis / Final Takeaways So Far

SonicMetrix has evolved from a WAV adherence checker into a feedback instrument for prompt engineering, musical analysis, and framework development.

## Latest Analysis: Pendulum

Files:

- `analyze_pendulum.py`
- `pendulum_whisper_small_en_transcript.json`
- `pendulum_lyrics_draft_small_en.md`
- `pendulum_analysis_record.json`
- `pendulum_analysis_summary.md`
- `pendulum_temporal_map.html`
- `pendulum_1_analysis_record.json`
- `pendulum_1_analysis_summary.md`
- `pendulum_1_temporal_map.html`
- `pendulum_comparison.json`
- `pendulum_comparison.md`

Important provenance note:

- `PENDULUM.wav` and `PENDULUM (1).wav` are byte-identical by SHA-256.
- The analyzer emits both records for bookkeeping, but comparison values match because the audio is the same file content.

Prompt condition:

- No explicit temporal schema.
- Style prompt uses a compressed haunted ecosystem: Salem 1692 / witch trials / black magic / occult / hex / curse, black-yellow-orange palette, parchment/scribbling/whistling/screeching/wood/wind/crackling textures, chimes/bells/whistles/grandfather-clock accent.
- Lyric prompt casts the Serpent of Song around Prudence Putnam's gallows vengeance narrative.

New analysis lanes:

- `style_ecosystem`: first attempt to score category/compression prompting as performed sonic ecology.
- `vocal_possession`: proxy for the user's "briefly inhuman on purpose" claim: intelligible vocal identity plus high/air/noise edge around haunt, black magic, swarm, and final laugh cues.
- `curse_loop`: scores pendulum/penance/haunt repetition, direct-address `you`, noose reprise, and final laugh as a curse machine.

Results:

- Totality: 0.779
- Interpretive totality: 0.764
- Technical performance: 0.730
- Productive deviation: 0.714
- Schema emergence: 0.765
- Story emergence: 0.975
- Prompt transformation: 1.000
- Curse loop: 1.000
- Vocal possession proxy: 0.688
- Style ecosystem: 0.327
- Framework adherence to inferred arc: 0.789
- Structural coherence: 0.728
- Spectral semantic: 0.566
- Local priority alignment: 0.567
- Key B major
- Tempo 70 BPM

ASR lyric evidence:

- No embedded lyrics beyond Suno metadata.
- ASR recovered the supplied lyric almost cleanly, including:
  - "My head's in a noose"
  - "I could set fire to the town"
  - "All of Salem's sinners"
  - "I could drown every judge with my blood"
  - "black magic isn't love"
  - "Pendulum, penance done"
  - "We will haunt you"
  - "coming back as a swarm of horseflies"
  - final laugh: "Ha ha ha ha ha."

Interpretation:

- This strongly supports the new methodology: style categories can behave as compressed prompt ecology when the framework gives Suno enough operating grammar.
- The narrative and curse-loop lanes support the user's ear: this is not merely following lyrics, it turns repetition and reprise into a performed vengeance machine.
- The vocal-possession lane partially captures the "briefly inhuman but intentional" quality.
- The `style_ecosystem` score is likely undercalibrated. It currently overweights global spectral signs like constant high-air/crackle/noise. Pendulum shows haunted ecology may appear through vocal persona, ritualized phrasing, sparse low-mid body, sectional cue behavior, and final laugh rather than constant noisy texture.
- Next scoring improvement: split style ecology into global texture, momentary cue texture, vocal embodiment, and lyric-environment coherence instead of one mostly spectral global score.
- Follow-up implemented: `semantic_atmosphere_embodiment` was added to `analyze_pendulum.py`. It scored 0.712, while the narrower `style_ecosystem` stayed 0.327. This captures the calibration distinction: the track becomes the Salem/curse world through story, vocal embodiment, ritual recurrence, cue behavior, and low-pressure haunted texture even when global texture proxies are modest.

## Latest Analysis: Tar-Smudged Saxophone

Files:

- `analyze_tar_smudged_saxophone.py`
- `tar_smudged_saxophone_whisper_small_en_transcript.json`
- `tar_smudged_saxophone_lyrics_draft_small_en.md`
- `tar_smudged_saxophone_analysis_record.json`
- `tar_smudged_saxophone_analysis_summary.md`
- `tar_smudged_saxophone_temporal_map.html`
- `tar_smudged_saxophone_1_analysis_record.json`
- `tar_smudged_saxophone_1_analysis_summary.md`
- `tar_smudged_saxophone_1_temporal_map.html`
- `tar_smudged_saxophone_comparison.json`
- `tar_smudged_saxophone_comparison.md`

Important provenance note:

- `Tar-Smudged Saxophone.wav` and `Tar-Smudged Saxophone (1).wav` are byte-identical by SHA-256.
- Duration is 326.28s. The "shorter version" the user mentioned is not represented by these two paths.

Prompt condition:

- User described this as their most evolved prompt methodology.
- Style layer is a dense ontology/compression engine: smoke-filled dark rooms, underground drug deals, danger/risk/isolation/addiction, tar-smudge smoke, saxophone in mourning, devastated piano, trembling trumpet, gravity pressure crush, snare storm thunder, imprisonment/suffocation, fever dream void, singularity.
- Director's note explicitly grants Suno permission to shift/adjust/edit/optimize and asks for a high-incoherence epistemic experience.
- Lyric layer supplies Dantavius Disco persona, vocal/aura/technique tags, a Dark Void Diamond choir, repeated Black Hole / Come Back / Alone / Obsession loops, Heavy Crown transformation, TIK/TOK death cue, gunshot phonetics, post-mortem female/Diamond persona, and final alone/throne resolution.

New analysis lanes:

- `style_coil`: scores the style layer as a coiling engine around the lyric framework: tar/smoke texture, doom-jazz mourning body, gravity pressure, fever-dream motion, cue response, and lyric-story coupling.
- `non_temporal_cues`: separates literal cue hits from adaptive substitutions for handles like `Heh`, `TIK/TOK`, `GLBLAH`, `record skrrt stop`, and post-mortem female persona.
- `persona_register`: rough proxy for Dantavius register/persona using low-body pressure, ASR clarity, heavy/crown anchors, and whether the female post-mortem persona appears.

Results:

- Totality: 0.774
- Interpretive totality: 0.761
- Technical performance: 0.779
- Productive deviation: 0.718
- Schema emergence: 0.817
- Story emergence: 0.998
- Style coil: 0.592
- Obsession loop: 1.000
- Non-temporal cue handling: 0.620
- Persona/register proxy: 0.761
- Prompt transformation: 1.000
- Framework adherence to inferred entropy arc: 0.777
- Structural coherence: 0.772
- Spectral semantic: 0.581
- Key A# minor
- Tempo 63 BPM

ASR lyric evidence:

- No embedded lyrics beyond Suno metadata.
- ASR recovered very clear anchors:
  - "If I fall into the black hole / void / abyss"
  - six `come back to me` anchors
  - twenty-six `alone` anchors
  - three `obsessed` lines
  - "Heavy is he..." / "Who wears the crown"
  - "The weight of a lone king's crown"
  - "I'm better doing this alone"
  - "Another bump, I'm back in the zone"
  - "Six feet deep in the enemy zone"
  - "Your last time on West Oak Drive"
  - "Time, time to die"
  - long wordless "Whoa" bridge/outro

Interpretation:

- This is strong evidence for the style-section-as-coil hypothesis. The style layer appears to condition how the lyric framework is performed, especially through gravity pressure, fever flux, isolation loop, and mourning/doom-jazz body.
- Literal non-temporal cue retention was low: ASR did not recover `Heh`, `TIK/TOK`, `GLBLAH`, `record stop`, Diamond/funeral, or the female post-mortem persona.
- Adaptive substitution was high: Suno retained the time-to-die function, alone/throne resolution, and transformed much of the late violent/post-mortem script into a long wordless bridge.
- Because the user explicitly gave permission to edit/optimize, this should be scored as productive deviation rather than simple failure.
- Methodology update: temporal allocation can likely be added without exact timestamps by assigning entropy/role budgets to sections, cues, and personas. Example: "front 20% establishes cosmology, middle 40% deepens addiction/alone loop, final 25% shifts into post-mortem/void aftermath; let exact timing breathe."
- Analyzer direction: add `temporal_entropy_allocation` and `style_coil` as reusable lanes. Human cue UI should support cue handles that are not words but functions: `inhalation`, `clock`, `gunshot`, `record_stop`, `persona_handoff`, `wordless_bridge`, `post_mortem_return`.
- Follow-up implemented: `semantic_atmosphere_embodiment` was added to `analyze_tar_smudged_saxophone.py` and documented in `sonicmetrix_semantic_atmosphere_embodiment.md`.
- Tar-Smudged now scores Semantic Atmosphere Embodiment at 0.728 and Semantic Pressure Fit at 0.783. This specifically addresses the issue where `Heavy Crown Transformation` and `Threat / Clock / Die` had modest observed 0-10 intensity but may still embody heavy/cold danger via low pressure, repetition, and fever-dream motion.
- Current principle: "Intensity fit is modest, but semantic atmosphere fit is strong" is a valid SonicMetrix conclusion, not a contradiction.

## Latest Analysis: Verdigris Verdict

Files:

- `schematic_judge_serpent_suno_ready.md`
- `analyze_verdigris_verdict.py`
- `verdigris_verdict_whisper_small_en_transcript.json`
- `verdigris_verdict_lyrics_draft_small_en.md`
- `verdigris_verdict_analysis_record.json`
- `verdigris_verdict_analysis_summary.md`
- `verdigris_verdict_temporal_map.html`

Prompt condition:

- First major test of the compressed 5x10x5x10 style methodology:
  - Style box was only 281 characters.
  - Lyric box was 4666 characters.
- Core question: "Can the Judge measure the Serpent without killing the song?"
- Prompt deliberately left gaps for Suno to complete as third voice, hook, echo, refusal, verdict, or ambience.
- Temporal ambience was specified as role/entropy feel, not exact timestamps.

Important title finding:

- Suno titled the song `Verdigris Verdict`.
- `Verdigris` comes directly from the compressed style color/material field.
- `Verdict` comes directly from the core judgment question.
- This is strong evidence that Suno used the song/title to answer from the semantic architecture, not merely sing supplied text.

Results:

- Totality: 0.864
- Interpretive totality: 0.842
- Technical performance: 0.779
- Productive deviation: 0.774
- Story answer: 0.984
- Duet completion: 1.000
- Semantic atmosphere embodiment: 0.881
- Title semantics: 1.000
- Ambience evidence: 1.000
- Schema emergence: 0.858
- Framework adherence to answer arc: 0.859
- Structural coherence: 0.789
- Spectral semantic: 0.524
- Key D major
- Tempo estimate 171 BPM, low confidence

ASR lyric evidence:

- No embedded lyrics beyond Suno metadata.
- ASR recovered the skeleton with surprising clarity:
  - "Bring in the song... Let the spine show, let the breath confess"
  - "I did not break the silence... I left a door for it to enter in"
  - "You are accused of beauty... mercy... singing..."
  - "If zero is an absence... If ten is only thunder..."
  - "Can I measure you without making you small?"
  - "If the cage becomes a mirror..."
  - "I kept the ash... missing syllable decide its final form"
  - "Then tell me what the song becomes... it becomes"
  - wordless `Ay` bridge at the gap
  - "I have seen perfect cages call themselves light"
  - "If the number has a heartbeat, if the silence has a tongue"
  - "What is a framework? A nervous system for flame"
  - "One bell... parchment breath... Clock stops or becomes a heartbeat"

Interpretation:

- This is the clearest evidence so far that a minimal compressed style layer can seed a semantic ecosystem while the lyric layer carries the open architecture.
- Suno did not over-explain the gap. It answered `it becomes...` with a wordless `Ay` bridge, then returned to the verdict structure.
- The final answer preserved the desired framework framing: `framework = nervous system for flame`, not cage.
- The analyzer added a new `answer_behavior` style profile through `story_answer`, `duet_completion`, `title_semantics`, and `ambience_evidence`.
- Methodology update: when testing model agency, deliberately leave one or two semantically charged absences. If Suno fills them musically and the answer is recoverable in ASR/structure/title/ambience, that is measurable evidence of collaborative completion.

## Phase Transition: Proof -> Refinement

File:

- `sonicmetrix_phase_transition_note.md`

Verdigris Verdict marks a project posture shift.

Earlier SonicMetrix work was partly defensive: prove that the Stochastic Storytelling Schema Framework was audible, measurable, and useful. The accumulated analyses now show enough measurable improvement over time to move the emphasis from proving the framework toward refining it intentionally.

New central question:

```text
What does the framework learn when the model uses it back at us?
```

Important refinement from Verdigris:

- `0` and `10` are not surface intensity values.
- They are measures of applied effort in local semantic context.
- A `0` can hold its breath.
- A `10` can whisper death.

Next scoring priority:

- `applied_effort_alignment`: whether the track applies the right kind and amount of effort for the local semantic task.
- `semantic_atmosphere_embodiment`: whether the track becomes the world described.
- `answer_behavior`: whether the model answers a prompt-level question through title, structure, lyric mutation, ambience, or gap completion.
- `framework_refinement_signal`: rare but important; mark cases where the generated song clarifies or corrects the framework itself.

Project direction:

- Less courtroom, more forge.
- The analyzer should still preserve evidence rigor, but its highest role is now to help the framework become sharper through the prompt -> song -> measurement -> interpretation -> revision loop.

Core conceptual lanes to preserve:

- `framework_adherence`: fit to explicit or inferred structure.
- `schema_emergence`: whether a 0-10-like arc appears without a full numeric spine.
- `story_emergence`: whether Suno turns myth/persona/narrative material into performed story.
- `prompt_transformation`: whether Suno transforms instructions into lyrics rather than quoting or looping them.
- `productive_deviation`: whether autonomous choices improve the song while preserving framework spirit.
- `local_priority_alignment`: whether 10 behaves as local priority, not merely loudness.
- `budgetary_sacrifice`: whether 0 behaves as pressure release, stored voltage, restraint, or strategic retreat rather than silence.
- `obsession_loop`: whether repetition becomes psychological/emotional gravity.
- `cosmology_texture`: whether style ingredients produce measurable sonic texture.
- `voice_constraint`: whether vocal/timbre constraints are actually reflected in the audio.

Prompt families discovered:

1. Direct Schema Prompting
   - Uses explicit 0-10 spines, section timings, Music API, Vocal Style, and cue tags.
   - Best for measuring literal adherence, local priority, semantic summons, and temporal structure.
   - Risk: over-commanding Suno or causing it to comply mechanically rather than musically.

2. Lyric-Channel Framework Prompting
   - Style prompt stays atmospheric; lyric prompt carries spines, persona, entropy, and section behavior.
   - Major discovery from `Mercy Learns My Name`: the lyric section may be stronger than the style section for framework execution.
   - Best for songs where structure should wrap around lyrics.

3. Spectral / Semantic Cue Prompting
   - Uses cue words like breath, static, weight, shatter, rupture, hammer, light, silence.
   - Best for testing short-window sonic responses.
   - Needs spectral texture analysis, not just loudness.

4. Myth Prompting
   - Supplies a dramatic world, personas, stakes, and symbolic conflict.
   - Major discovery from `Sick-Sweet Seraphim` and `Hydra of Incoherency`: Suno can perform or construct story from mythic material.
   - Best for story emergence and autonomous composition.
   - Risk: if myth text is too singable, Suno may quote it directly.

5. Framework-Trust Prompting
   - Tells Suno to use the framework as an operating grammar while choosing musical execution itself.
   - Best for testing model agency and productive deviation.
   - Needs `prompt_transformation` scoring to catch instruction retention.

6. Budgetary Sacrifice Prompting
   - Treats 0 as pressure budget, computational relaxation, tactical restraint, or stored voltage.
   - Major discovery from `Exiled King's Glass`: a 0 can remain alive and charged, not silent.
   - Best for refining the meaning of 0 beyond stop/dropout.

7. Cosmology/Ontology Prompting
   - Supplies conceptual fields rather than explicit schema: cosmology, ontology, colors, textures, accents.
   - Major discovery from `Buzzing Black Hole`: this can score high totality without a visible numeric spine.
   - Best for latent schema emergence, emotional gravity, and repeated lyric loops.
   - Weak point: texture/timbre constraints need concrete sound-design language if strict adherence matters.

8. Loop Prompting
   - Uses repetition as the musical/psychological machine.
   - `Buzzing Black Hole` showed that repeated lyric lines can become measurable obsession/loss-of-agency pressure.
   - Best for measuring event-horizon persistence, recursion, mantra, collapse, and fixation.

Important prompt-design lessons:

- Style should often be style: palette, emotional field, genre, texture, repair logic.
- Lyric section is powerful for structure: section behavior, persona, entropy, cue behavior, and singable anchors.
- Instructions should be dry and clearly marked if they should not be sung.
- Singable instructions may become lyrics.
- If original lyric generation is desired, say: "Do not quote this narration directly; transform it into original lyrics."
- If direct myth-performance is acceptable, allow narration-like material to remain poetic.
- If a non-human voice is desired, describe timbre operationally: vocoder, chopped phonemes, sample-pad trigger, monotone playback, telephone-band speaker, synthetic announcer, dehumanized call-and-response.
- If 0 is important, clarify its role: silence, breath, pressure release, withheld strike, stored voltage, negative space, or controlled mid-density retreat.
- If 10 is important, clarify whether it is volume, vocal range, spectral brightness, emotional priority, arrangement density, or local destiny.

Best next app direction:

- Build a distinct SonicMetrix player / visualizer version.
- It should not only show scores after analysis. It should play the track while visualizing evidence layers:
  - waveform / RMS energy
  - observed 0-10 curve
  - spectral bands and texture
  - ASR lyric segments
  - semantic cue markers
  - budgetary 0 windows
  - local 10 priority peaks
  - story/ontology loop regions
  - prompt-retention risk regions
  - productive-deviation notes
- This player can become a prompt feedback instrument: Prompt -> Song -> Analysis -> Visual Evidence -> Prompt Patch -> Better Song.

Best next scoring direction:

- Consolidate duplicated analyzers into a shared `sonicmetrix_core.py`.
- Promote common lanes into shared schema:
  - `schema_emergence`
  - `story_emergence`
  - `prompt_transformation`
  - `productive_deviation`
  - `budgetary_sacrifice`
  - `obsession_loop`
  - `cosmology_texture`
  - `voice_constraint`
- Keep song-specific analyzers as thin prompt profiles rather than full copied scripts.

Highest-value research question:

How much structure does Suno need, and what kind?

The project now suggests the answer is not "more instruction" or "less instruction." It is:

- enough symbolic gravity to create the intended probability field
- enough structure to guide the song's architecture
- enough freedom for Suno to make productive musical choices
- enough analysis to learn which kind of prompt pressure worked

The practical goal is no longer just scoring a song. The goal is learning how to make the next song better.
