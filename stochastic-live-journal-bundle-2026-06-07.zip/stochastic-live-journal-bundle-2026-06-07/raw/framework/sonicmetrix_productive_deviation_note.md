# SonicMetrix Productive Deviation Lane

## Purpose

`model_agency_credit` says a model deviation did not break the prompt.

`productive_deviation` says a model deviation made the song better while preserving the framework's spirit.

This distinction matters because a generated song can be less literally adherent and still be the stronger artistic object.

## Proposed Formula

```text
productive_deviation =
useful_deviation_shape
+ listener_preference
+ framework_spirit_preserved
modulated by literal_deviation
```

The current Hush Kernel implementation uses:

- `literal_deviation`: how far the output departs from exact prompt targets, based on adherence, coherence, and prompt stretch.
- `useful_deviation_shape`: whether the deviation is in a useful middle band rather than unbounded drift.
- `listener_preference`: human preference credit.
- `framework_spirit_preserved`: composite of spectral cue fit, corruption/no-seal behavior, local priority, model agency, and structural coherence.

## Why Useful Deviation Shape Exists

More deviation is not always better.

For Hush Kernel:

- `Hush Kernel 2.wav` stretches the prompt to 1.42x and wins listener preference.
- `Hush Kernel (1).wav` stretches the prompt to 2.28x and strongly expresses no-seal behavior, but reads less clearly as the preferred productive compromise.

The productive-deviation lane should reward useful model collaboration, not every extreme departure.

## Hush Kernel Result

```text
Hush Kernel 2.wav:
productive_deviation = 0.614
literal_deviation = 0.248
useful_deviation_shape = 0.971
listener_preference = 0.900
framework_spirit_preserved = 0.579

Hush Kernel (1).wav:
productive_deviation = 0.423
literal_deviation = 0.406
useful_deviation_shape = 0.276
listener_preference = 0.760
framework_spirit_preserved = 0.684
```

## Interpretation

`Hush Kernel (1).wav` still scores higher on strict evidence-totality because it strongly fulfills no-seal and corruption residue.

`Hush Kernel 2.wav` scores higher on Productive Deviation because its deviations appear to improve listener preference while preserving the sweet/dark viral-lullaby superposition.

This gives SonicMetrix a way to say:

```text
The model did not merely deviate.
The model collaborated productively.
```
