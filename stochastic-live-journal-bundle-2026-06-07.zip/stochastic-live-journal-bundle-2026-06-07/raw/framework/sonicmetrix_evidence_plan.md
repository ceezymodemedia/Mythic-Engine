# SonicMetrix Evidence Plan

## Core Goal

Build a DAW-like analysis app that imports one or more WAV files, extracts reproducible audio evidence, maps that evidence onto the Stochastic Storytelling Schema Framework, and exports a defensible record of what was analyzed, what was observed, what was inferred, and how confident the system is.

The app should treat the framework as a layered translation system:

- Spine: narrative arc, attention curve, rupture/resolution pattern
- Meaning: theme, emotional polarity, symbolic anchors
- Timing: segment boundaries, beat/section duration, silence and negative space
- Melodic Velocity: motion, acceleration, contour, energy shifts
- Sonic: timbre, density, instrumentation, mix pressure
- Lyrical Inflection: vocal delivery, phrase stress, emotional stance
- Style: prompt language, genre blend, production instructions, schema tags

## Strongest Evidence Already Present

- The PDF defines a 0-10 compressed instruction system where digits represent controllable intensity, attention, and narrative weight.
- Zero has a special semantic role: intentional silence, negative space, conservation, and reset.
- Temporal mapping matters: each digit can represent roughly 0.5 to 1.5 seconds, so the schema is not only symbolic but time-addressable.
- The proof-of-concept JSON already includes mean amplitude, peak amplitude, RMS, velocity, kinetic energy, Shannon entropy, qualitative mapping, rupture gate, friction state, and adherence score.
- The SonicMetrix HTML already frames the report as a quantitative/qualitative audit with act-level mapping, entropy log, 0-10 scale, and methodology adherence score.

## Areas To Add For Stronger Evidence

1. File provenance

Record the source filename, file size, SHA-256 hash, duration, sample rate, bit depth, channel count, codec/container details, import timestamp, and analysis software version. This makes every report reproducible.

2. Segmentation evidence

Do not only analyze the whole track. Segment by silence, novelty, onset density, chorus/verse-like boundaries, and user-defined schema windows. Each segment should have start time, end time, duration, detected rationale, and linked framework layer.

3. Loudness and dynamics

Add integrated LUFS, short-term LUFS, momentary loudness, true peak, crest factor, dynamic range, clipping count, zero-crossing rate, RMS envelope, and silence ratio. These support claims about rupture, negative space, density, and impact.

4. Spectral/timbral evidence

Add spectral centroid, rolloff, bandwidth, flatness, contrast, MFCC summary, harmonic/percussive ratio, low/mid/high band energy, brightness, noisiness, and transient density. These support Style, Sonic Layer, and instrumentation claims.

5. Rhythmic/motion evidence

Add tempo estimate, beat grid confidence, onset rate, pulse stability, syncopation proxy, energy velocity, acceleration, jerk, and section-to-section deltas. These support Melodic Velocity and Timing.

6. Silence and zero-command detection

Track intentional dropouts, near-silence windows, pre-impact gaps, post-impact decay, and contrast ratio before/after silence. This directly validates the framework's special role for 0.

7. Rupture and constructive interference detection

Detect moments where multiple features spike together: loudness, spectral centroid, onset density, bass energy, vocal energy, harmonic density, and section contrast. These can be candidate rupture gates or 8-10 events.

8. Vocal and lyric evidence

When lyrics or stems are available, align lyrics to time and detect delivery cues: breathiness, belting, spoken delivery, density of syllables, repetition, call-and-response, choir/layering cues, and emotional valence. Keep these as evidence with confidence, not absolute truth.

9. Prompt/schema comparison

Input the intended schema, style prompt, lyrics, and generation settings. Compare intended 0-10 values against observed track features over time. Export match/mismatch moments.

10. Model agency and creative deviation

Track moments where the model appears to make a musically intelligent choice that was not directly instructed. These should not automatically reduce adherence. Mark them as creative deviations, quote the expected instruction, quote or describe the observed result, and score whether the deviation supports or undermines the framework's intent.

11. Confidence and audit trail

Every conclusion should cite the supporting measurements and time ranges. Human overrides should be recorded separately from machine detections. The app should say "inferred" when it is interpreting, and "measured" when it is reading signal data.

## Recommended Input Package

Minimum useful input:

- WAV file
- Intended framework name/version
- Optional intended 0-10 sequence
- Optional style prompt
- Optional lyrics

Best input:

- WAV file or stems
- Prompt/style text used to generate the track
- Lyrics with section labels
- Intended Spine, Lyric, Melody, and Music API schemas
- Target duration and intended temporal unit size
- Known song sections, if any
- Human notes about expected rupture gates, zero commands, friction states, and climax points
- Model/generator metadata, if available

## Report Shape

The exported report should include:

- Analysis metadata
- File provenance
- Global measurements
- Time-segment table
- Feature timeline
- Framework layer mapping
- Intended-vs-observed schema comparison
- Evidence-backed narrative interpretation
- Model agency / creative deviation log
- Confidence scores by claim
- Human notes and overrides
- Raw JSON export

## First App Milestone

The first practical build should be an offline local web app with:

- WAV upload/drop zone
- waveform view
- segment timeline
- global metrics panel
- per-segment metrics table
- schema input editor
- 0-10 observed curve
- claim/evidence inspector
- JSON report export

The key design principle: the app should never merely say "94% adherence." It should show which moments earned that score.
