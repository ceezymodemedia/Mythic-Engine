# SonicMetrix Spectral Processing Roadmap

## Short Answer

Yes, deeper spectral processing analysis is possible with local WAV data. SonicMetrix already uses RMS, entropy, velocity, spectral centroid, pitch proxy, stereo width, rhythm proxies, and observed 0-10 curves. The next layer should measure spectral texture and transformation, especially around human cue markers.

## Why It Matters For The Framework

The framework is no longer only asking whether a section got louder. It asks whether a cue changed the sound in the right way:

- `breath` should add air/noise without necessarily increasing loudness.
- `static` should increase noisiness, flatness, or high-frequency grain.
- `screech` should create a short high-centroid / high-band spike.
- `weight` should create low or low-mid pressure, even if it is not the loudest point.
- `mercy` should soften harshness or widen warmth.
- `break` should create instability, crack, transient fracture, or glitch tail.
- `silence` should reduce energy and/or remove texture.

That means each cue needs its own spectral fingerprint.

## Candidate Metrics

### Spectral Flatness

Measures how noise-like a frame is. Useful for:

- static
- glitch dust
- breath texture
- granular smear
- bitcrush-like roughness

High flatness often means a more noise-like spectrum; low flatness often means more tonal/harmonic content.

### Band Energy Ratios

Split the signal into bands:

- sub: 20-80 Hz
- low: 80-250 Hz
- low-mid: 250-700 Hz
- mid: 700-2000 Hz
- high: 2000-6000 Hz
- air: 6000-12000 Hz

Useful mappings:

- `weight`: sub + low + low-mid rise
- `screech`: high + air rise
- `breath`: air rise without large RMS rise
- `heat`: mid/high rise plus velocity
- `mercy`: high harshness falls while stereo warmth/width rises

### Spectral Roll-Off

The frequency below which most spectral energy sits. Useful for:

- brightness
- harshness
- screech detection
- softening after `mercy`

### Spectral Flux By Band

Measures rapid spectral change over time. Useful for:

- glitch tails
- crack/fracture events
- drum/transient changes
- violin punctuations

The current analyzer has broad flux proxies. A stronger version should compute flux per band and per short cue window.

### Zero Crossing Rate

Already used globally, but it can be localized. Useful for:

- noisy consonants
- breath/fry
- static
- distortion edge

### Harmonic / Noise Proxy

Without full source separation, a practical proxy can compare:

- pitch confidence
- spectral flatness
- zero crossing rate
- high-band energy

This can help distinguish:

- tonal violin sustain
- noisy breath
- glitch/static
- raspy vocal edge

### Short-Window Cue Analysis

Some cue events happen too fast for 5-6 second windows. Use multiple windows:

- immediate: 0.0-1.5s after cue
- near: 1.5-4.0s after cue
- aftermath: 4.0-8.0s after cue

Then score by cue type:

- `stop`: immediate energy/motion collapse
- `screech`: immediate high-band spike
- `break`: immediate instability plus aftermath glitch tail
- `mercy`: near-window harshness reduction and width/warmth increase

## Proposed Record Additions

Add to `temporal_analysis`:

```json
{
  "spectral_texture": {
    "timeline": [],
    "global": {},
    "cue_responses": []
  }
}
```

Each timeline row should include:

- `spectral_flatness`
- `spectral_rolloff_hz`
- `sub_energy`
- `low_energy`
- `low_mid_energy`
- `mid_energy`
- `high_energy`
- `air_energy`
- `band_flux_sub`
- `band_flux_low_mid`
- `band_flux_high`
- `harmonic_noise_proxy`

Each cue response should include:

- pre / immediate / near / aftermath windows
- best matching spectral fingerprint
- cue-specific evidence score
- supporting timeline rows

## Implementation Priority

1. Add `spectral_texture_analysis(mono, sr)` to the shared engine.
2. Add band-energy and flatness fields to temporal map hover/readout.
3. Add cue-specific short-window scoring.
4. Add a spectral-lane chart to the HTML map.
5. Add comparison deltas for twin tracks.

## Important Caution

Without stem separation, these are mix-level proxies. SonicMetrix should phrase claims carefully:

- measured: "high-band energy rose"
- inferred: "this supports a screech/static cue"
- human-calibrated: "listener identified this as violin screech"

That keeps the evidence honest while still allowing the framework to learn.
