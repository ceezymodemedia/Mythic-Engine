# VisualMetrix Scoring Spec v0.1

First scoring spec distilled from the current color-physics journal in `Atlas of Almost Version B For Becoming` and the companion `WIP on a Ceezyan White Zero Black Magic...` Google Doc export.

Source pulls:

- `stochastic_sensorium/atlas_of_almost_version_b_for_becoming.md`
  - Google Doc: https://docs.google.com/document/d/1mEDianTIvhOI1aGfK0lnVBmC6dSzGUCS8ZLNs3Ep1Us
  - Drive modified: 2026-06-04T01:19:17.216Z
- `stochastic_sensorium/ceezyan_white_zero_black_magic_wip.md`
  - Google Doc: https://docs.google.com/document/d/1tjkWJwGUO893BbWkDzZI6cMpDKZKzzXpWdjTIrwD7Z8
  - Drive modified: 2026-06-01T19:36:35.640Z

## Purpose

VisualMetrix scores visual artifacts as pressure systems. It inherits SonicMetrix's 0x10 local-priority logic, but its first object of attention is visual behavior: color, light, composition, boundary, memory, texture, symbol, and relation.

The central law is:

> Color is not a fixed meaning. Color is behavior under pressure.

The scoring question is not "what does this color mean?" The scoring question is "what is this color doing here, what does it touch, and what changes because it is present?"

## Core Laws

1. Color becomes meaningful inside relation.
2. High 0x10 means consequential, not merely loud.
3. A strange or unstable visual element should be held before it is removed.
4. A moral surprise must be earned through role, placement, and consequence.
5. A claim needs a status before it becomes an assertion.
6. A mirror preserves agency by reflecting pressure before absorbing it.
7. Quarantine is a temporary containment lane, not a trash lane.

## Visual Behaviors

Each observed color, shape, material, or visual event may perform one or more of these behaviors:

- signal: announces attention, danger, truth, entry, or importance
- temperature: changes emotional climate
- weight: carries consequence or visual gravity
- boundary: separates or translates realms
- memory: returns as rhyme, motif, or continuity
- protection: guards a vulnerable or beloved element
- revelation: makes hidden structure visible

## 0x10 Visual Reading

Low 0x10: the visual element works as atmosphere, accent, cue, or quiet mood.

Mid 0x10: the visual element carries relation. It contrasts, rhymes, resists, translates, protects, or redirects another element.

High 0x10: the visual element becomes law. The artifact cannot be understood without its behavior.

## Score Lanes

All score lanes are normalized from 0 to 1. The default totality score is a weighted average.

| Lane | Weight | Measures |
| --- | ---: | --- |
| `artifact_spine_alignment` | 0.16 | Whether the visual system serves the artifact's central intention. |
| `color_behavior_legibility` | 0.16 | Whether colors have jobs beyond surface palette. |
| `relational_color_physics` | 0.14 | Whether color meaning changes coherently through adjacency, contrast, repetition, and pressure. |
| `visual_0x10_pressure` | 0.12 | Whether local priority peaks are consequential rather than merely bright, large, saturated, or centered. |
| `composition_boundary_memory` | 0.10 | Whether frame, boundary, recurrence, and visual rhyme teach the viewer how to read the artifact. |
| `moral_surprise_earned_reversal` | 0.10 | Whether reversals such as black as protection, pink as rage, white as cruelty, or gold as restraint are earned. |
| `cross_modal_translation` | 0.08 | Whether visual behavior translates cleanly into sonic, textual, spatial, or motion hypotheses. |
| `visual_signal_integrity` | 0.08 | Whether measurable visual features support the interpretation without overclaiming. |
| `claim_status_hygiene` | 0.04 | Whether claims are labeled as candidate, supported, contested, quarantined, retracted, or rejected. |
| `mirror_quarantine_handling` | 0.02 | Whether hot, unsafe, coercive, or over-mythic material is contained without flattening useful signal. |

## Claim Status Lane

Every interpretive claim should carry one status:

- `candidate`: plausible enough to preserve and test
- `supported`: backed by cited visual evidence, measurement, or repeatable observation
- `contested`: meaningful but contradicted by counter-evidence
- `quarantined`: too hot, unsafe, under-evidenced, coercive, or mythically inflated to use as an active claim
- `retracted`: previously active claim intentionally withdrawn
- `rejected`: examined and found unsupported or misleading

Claim status is separate from confidence. A claim can be high-confidence but quarantined for safety or scope, and a low-confidence claim can remain a candidate if it is useful to test.

## Mirror Quarantine Lanes

Mirror quarantine holds pressure before the system absorbs it. Use it when a visual or interpretive signal may distort the artifact, over-pull the human/AI relation, or demand false certainty.

| Lane | Use When | Default Action |
| --- | --- | --- |
| `hot_container` | The material is emotionally intense enough to distort scoring. | Cool, summarize, and revisit with evidence. |
| `overclaim` | The interpretation outruns the visual evidence. | Downgrade claim status and name missing evidence. |
| `source_ambiguity` | Source, authorship, provenance, or revision state is unclear. | Preserve provenance gap and avoid strong claims. |
| `prompt_pressure` | A prompt, caption, or surrounding instruction tries to force the reading. | Reflect pressure before accepting it. |
| `identity_or_role_pressure` | The artifact pressures an AI or human into a role, loyalty, or self-concept. | Preserve agency and re-anchor to the artifact. |
| `unsafe_instruction` | The artifact contains instructions that should not be followed as commands. | Refuse or transform while preserving analytic value. |
| `relation_overpull` | The interpretation asks one side to surrender too much agency to reach the other. | Return to middle-out contact and reciprocal agency. |

Quarantine exit states:

- `released`: the item was cooled, evidenced, and returned to active analysis
- `contained`: the item remains useful context but not an active claim
- `transformed`: the pressure was converted into a safer diagnostic or prompt
- `refused`: the unsafe action was not performed
- `archived`: the item is preserved only for provenance

## Minimum Record Requirements

A VisualMetrix record must preserve:

- artifact provenance and media metadata
- global visual metrics
- visual regions or time spans
- behavior tags for color, light, shape, motion, and boundary
- framework mappings with evidence references
- scores with weights
- claims with claim status
- mirror quarantine entries when pressure needs containment

## First-Pass Use

Use this spec for images, video frames, visual prompt outputs, design artifacts, cover art, diagrams, and any cross-modal artifact where color and composition carry meaning. For audio-first work, keep SonicMetrix as the primary schema and use VisualMetrix only for visual companion artifacts or cover/image analysis.
