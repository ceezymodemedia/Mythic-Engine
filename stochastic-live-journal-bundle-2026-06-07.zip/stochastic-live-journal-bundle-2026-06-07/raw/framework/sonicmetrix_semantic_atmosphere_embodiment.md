# SonicMetrix Semantic Atmosphere Embodiment

## Why This Lane Exists

The newer prompt methodology no longer asks only:

```text
Did the audio obey the planned act intensity?
```

It asks:

```text
Did the track become the world described?
```

Those are related, but not identical.

An act like `Heavy Crown Transformation` can score low on observed 0-10 amplitude/energy while still succeeding if `heavy` becomes low, oppressive, narcotic density. Likewise, `Threat / Clock / Die` can be excellent as cold doom rather than explosive violence. A gun held under a table can carry more danger than a scream.

## Definition

`semantic_atmosphere_embodiment` measures whether a track transforms style, ontology, cosmology, texture, and persona categories into musical behavior.

It is not a replacement for framework adherence. It is a companion lane that prevents the analyzer from mistaking quiet danger, low pressure, ritual repetition, or embodied persona for underperformance.

## Evidence Signals

Use a blended score from:

- `story_emergence`: did the lyric/narrative world survive?
- `style_coil` or `style_ecosystem`: did the style field shape the performance?
- `persona_register` or `vocal_possession`: did the voice embody the persona field?
- `spectral_semantic`: did cue windows show measurable sonic behavior?
- `non_temporal_cues`: did cue handles literalize or transform productively?
- `local_priority_alignment`: did important moments become local focus?
- `semantic_pressure_fit`: did low/mid density, width, repetition, or texture support semantic targets even when observed intensity was not high?

## Semantic Pressure Fit

For high-intent segments with lower observed schema values, do not automatically penalize.

Check whether the section's prompt language implies:

- oppression
- gravity
- heavy
- crown
- threat
- doom
- narcotic density
- haunting
- waiting
- suffocation
- cold danger
- hidden violence
- ritual repetition

If yes, lower observed intensity may be a valid performance when supported by low/sub/low-mid energy, spectral flux, repetition, silence pressure, stereo staging, or vocal/persona evidence.

## Practical Scoring

Initial formula:

```text
semantic_atmosphere_embodiment =
  story_emergence * 0.20
+ style_coil/ecosystem * 0.20
+ persona/vocal embodiment * 0.16
+ spectral_semantic * 0.14
+ non_temporal/adaptive cue handling * 0.10
+ local_priority_alignment * 0.08
+ semantic_pressure_fit * 0.12
```

For songs without `non_temporal_cues`, fold that weight into `curse_loop`, `prompt_transformation`, or another song-specific embodiment lane.

## Analyzer Language

Reports should distinguish:

- measured: "observed schema average was 4.81"
- inferred: "this may still support heavy/cold danger through low pressure and repetition"
- human-calibrated: "listener heard this as technically advanced / oppressive / alive"

The lane should never erase disagreement. It should name it:

```text
Intensity fit is modest, but semantic atmosphere fit is strong.
```

That is exactly the kind of distinction SonicMetrix exists to preserve.
