# Stochastic Live Journal Bundle

Open `index.html` to browse the release locally.

This bundle was generated from:

`C:\Users\ceezy\Documents\Codex\2026-05-15\files-mentioned-by-the-user-sonicmetrix`

Primary sections:

- `framework/` rendered framework docs
- `analyses/` curated SonicMetrix reports
- `sensorium/` Stochastic Sensorium notes and card deck
- `maps/` copied temporal-map HTML files
- `raw/` source companion files
- `manifest.json` copied-file inventory with SHA-256 checksums
