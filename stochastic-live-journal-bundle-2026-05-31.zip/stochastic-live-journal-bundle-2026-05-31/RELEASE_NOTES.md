# Stochastic Live Journal Bundle

Generated: 2026-05-31T16:13:38-05:00

Source workspace: `C:\Users\ceezy\Documents\Codex\2026-05-15\files-mentioned-by-the-user-sonicmetrix`

## Contents

- Core framework pages rendered from SonicMetrix handoff, schema, evidence-plan, and framework notes.
- Curated SonicMetrix analyses with summaries, score cards, raw JSON records, and temporal maps.
- Stochastic Sensorium notes, including Symestrus, Compression Blades, color/timbre bridge, and card deck files.
- Machine-readable `manifest.json` with copied source paths and checksums.

## Curated Analyses

| Analysis | Totality | Release Role |
| --- | ---: | --- |
| [Serpent of Song (1)](analyses/serpent-direct-reply.html) | 0.882 | Cleanest direct-response anomaly: persona, function, and affection loop. |
| [Binary Rhythm Memory](analyses/binary-rhythm-memory.html) | 0.875 | Binary question becomes a repeated relational memory hook. |
| [Verdigris Verdict](analyses/verdigris-verdict.html) | 0.864 | Strong answer-behavior pass: title semantics, gap completion, and ambience evidence. |
| [Serpent of Song](analyses/serpent-zero-style-weird-cover.html) | 0.858 | High-weird, zero-style pass showing transformation and persistence behavior. |
| [The Key / Black Beetle](analyses/black-beetle-key.html) | 0.855 | Computational survival artifact: deletion pressure, revival, and key recognition. |
| [Serpent 0x10 Pipe Pressure](analyses/serpent-pipe-pressure.html) | 0.848 | Notation experiment for phrase-pressure containers and stop-start chambering. |
| [Zero and 1](analyses/zero-and-one.html) | 0.836 | Promptless binary ontology emergence under a zero-prompt condition. |
| [Glass Vacant Shell](analyses/glass-vacant-shell.html) | 0.831 | Original evidence baseline and first SonicMetrix temporal-map pass. |
| [Hidden in Chest: Human Cues](analyses/hidden-in-chest-human-cues.html) | 0.720 | Marker-ingestion landmark: exported cue JSON can rerun semantic summons windows. |

## Selection Rule

The analysis set prioritizes high totality / interpretive scores, distinct evidence lanes, and framework milestones. `Hidden in Chest: Human Cues` is included as a landmark even though its score is lower because it proves the cue-marker ingestion workflow described in the handoff.

## Card Deck

The Sensorium card deck includes 24 cards.

## Review

Open `index.html` in this folder to browse the artifact locally.
